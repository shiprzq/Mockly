import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { ownerKey } = req.query;
      if (!ownerKey) return res.status(400).json({ error: 'An owner key is required.' });
      const { data, error } = await supabase.from('mockly_assets').select('*').eq('owner_key', ownerKey).order('created_at', { ascending: false }).limit(30);
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id, ownerKey } = req.body;
      if (!id || !ownerKey) return res.status(400).json({ error: 'Asset and owner IDs are required.' });
      const { data: asset, error: findError } = await supabase.from('mockly_assets').select('*').eq('id', id).eq('owner_key', ownerKey).single();
      if (findError || !asset) return res.status(404).json({ error: 'Asset not found.' });
      const { error: storageError } = await supabase.storage.from('mockly-screenshots').remove([asset.path]);
      if (storageError) console.error('Storage cleanup:', storageError);
      const { error } = await supabase.from('mockly_assets').delete().eq('id', id).eq('owner_key', ownerKey);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Assets API error:', err);
    return res.status(500).json({ error: err.message || 'Asset request failed.' });
  }
}
