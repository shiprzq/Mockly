import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { id, ownerKey } = req.query;
      if (id) {
        const { data, error } = await supabase.from('mockly_projects').select('*').eq('id', id).single();
        if (error || !data) return res.status(404).json({ error: 'This scene could not be found.' });
        if (!data.is_shared && data.owner_key !== ownerKey) return res.status(404).json({ error: 'This scene is private or no longer available.' });
        return res.status(200).json(data);
      }
      if (!ownerKey || typeof ownerKey !== 'string') return res.status(400).json({ error: 'An owner key is required.' });
      const { data, error } = await supabase.from('mockly_projects').select('*').eq('owner_key', ownerKey).order('updated_at', { ascending: false }).limit(100);
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { ownerKey, name, config, device, screenshotUrl } = req.body;
      if (!ownerKey || typeof ownerKey !== 'string') return res.status(400).json({ error: 'An owner key is required.' });
      if (!name?.trim()) return res.status(400).json({ error: 'Give your project a name.' });
      if (!config || typeof config !== 'object') return res.status(400).json({ error: 'A valid scene configuration is required.' });
      const { data, error } = await supabase.from('mockly_projects').insert({
        owner_key: ownerKey,
        name: name.trim().slice(0, 80),
        config,
        device: device || config.device || 'phone',
        screenshot_url: screenshotUrl || config.screen?.url || null,
        is_shared: false,
      }).select('*').single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, ownerKey, name, config, device, screenshotUrl, isShared } = req.body;
      if (!id || !ownerKey) return res.status(400).json({ error: 'Project and owner IDs are required.' });
      const updates = { updated_at: new Date().toISOString() };
      if (name !== undefined) {
        if (!name.trim()) return res.status(400).json({ error: 'Project name cannot be empty.' });
        updates.name = name.trim().slice(0, 80);
      }
      if (config !== undefined) updates.config = config;
      if (device !== undefined) updates.device = device;
      if (screenshotUrl !== undefined) updates.screenshot_url = screenshotUrl || null;
      if (isShared !== undefined) updates.is_shared = Boolean(isShared);
      const { data, error } = await supabase.from('mockly_projects').update(updates).eq('id', id).eq('owner_key', ownerKey).select('*').single();
      if (error || !data) return res.status(404).json({ error: 'Project not found or you do not have access.' });
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id, ownerKey } = req.body;
      if (!id || !ownerKey) return res.status(400).json({ error: 'Project and owner IDs are required.' });
      const { error } = await supabase.from('mockly_projects').delete().eq('id', id).eq('owner_key', ownerKey);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Projects API error:', err);
    return res.status(500).json({ error: err.message || 'Project request failed.' });
  }
}
