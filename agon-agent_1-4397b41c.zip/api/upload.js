import supabase from './db-client.js';

const extensions = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp' };

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { ownerKey, fileName, fileBase64, contentType, width, height } = req.body;
    if (!ownerKey || typeof ownerKey !== 'string') return res.status(400).json({ error: 'An owner key is required.' });
    if (!fileBase64 || !extensions[contentType]) return res.status(400).json({ error: 'Choose a PNG, JPEG or WebP image.' });
    const buffer = Buffer.from(fileBase64, 'base64');
    if (!buffer.length || buffer.length > 3 * 1024 * 1024) return res.status(400).json({ error: 'Images must be smaller than 3 MB.' });
    const cleanName = String(fileName || 'screenshot').replace(/[^a-zA-Z0-9._-]/g, '-').slice(-80);
    const path = `${ownerKey.replace(/[^a-zA-Z0-9-]/g, '')}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${cleanName}`;
    const { error: uploadError } = await supabase.storage.from('mockly-screenshots').upload(path, buffer, { contentType, upsert: false });
    if (uploadError) throw uploadError;
    const { data: urlData } = supabase.storage.from('mockly-screenshots').getPublicUrl(path);
    const { data, error } = await supabase.from('mockly_assets').insert({
      owner_key: ownerKey,
      name: String(fileName || 'Screenshot').slice(0, 120),
      url: urlData.publicUrl,
      path,
      content_type: contentType,
      width: Number(width) || null,
      height: Number(height) || null,
    }).select('*').single();
    if (error) throw error;
    return res.status(201).json(data);
  } catch (err) {
    console.error('Upload API error:', err);
    return res.status(500).json({ error: err.message || 'Upload failed.' });
  }
}
