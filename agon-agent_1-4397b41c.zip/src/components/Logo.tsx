import { Link } from 'react-router-dom';

export default function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link to="/" className="group inline-flex items-center gap-2.5" aria-label="Mockly home">
      <span className={`grid h-8 w-8 place-items-center rounded-[10px] transition-transform group-hover:-rotate-6 ${light ? 'bg-[#d9ff68] text-[#171914]' : 'bg-[#1d201b] text-[#e4ff87]'}`}>
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
          <path d="M3 14.5V6.2c0-.9.7-1.6 1.6-1.6h10.8c.9 0 1.6.7 1.6 1.6v8.3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
          <path d="M3 8h14M6 6.1h.01M8.2 6.1h.01" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
          <path d="M6.5 14.5v-3l2 1.7 2-1.7v3M13.5 11.5v3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </span>
      <span className={`text-[22px] font-bold tracking-[-0.055em] ${light ? 'text-white' : 'text-[#1d201b]'}`}>mockly<span className="text-[#7e9c38]">.</span></span>
    </Link>
  );
}
