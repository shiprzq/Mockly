import type { SampleName } from '../lib/config';

const font = 'Arial, Helvetica, sans-serif';

function StatusBar({ dark = false }: { dark?: boolean }) {
  const color = dark ? '#f7f7ef' : '#191c18';
  return <g fill={color} fontFamily={font} fontSize="15" fontWeight="700"><text x="38" y="38">9:41</text><path d="M318 31h4v7h-4zm7-4h4v11h-4zm7-4h4v15h-4z" /><rect x="344" y="24" width="25" height="13" rx="4" fill="none" stroke={color} strokeWidth="1.5" /><rect x="347" y="27" width="16" height="7" rx="2" /><path d="M371 28v5" stroke={color} strokeWidth="2" strokeLinecap="round" /></g>;
}

function Orbit({ title, accent }: { title: string; accent: string }) {
  return <>
    <rect width="390" height="844" fill="#121510" />
    <StatusBar dark />
    <g fontFamily={font}>
      <text x="28" y="88" fill="#a8ada2" fontSize="14">OVERVIEW</text>
      <text x="28" y="125" fill="#f5f6ef" fontSize="30" fontWeight="700">{title}</text>
      <circle cx="334" cy="108" r="23" fill="#262b23" /><circle cx="334" cy="108" r="8" fill={accent} />
      <text x="28" y="190" fill="#a8ada2" fontSize="15">Total balance</text>
      <text x="28" y="239" fill="#f7f8f1" fontSize="42" fontWeight="700" letterSpacing="-1.8">$24,680<tspan fontSize="24" fill="#a8ada2">.20</tspan></text>
      <rect x="28" y="264" width="108" height="30" rx="15" fill="#283321" /><circle cx="45" cy="279" r="4" fill={accent} /><text x="56" y="284" fill={accent} fontSize="12" fontWeight="700">+ 8.4% this month</text>
      <rect x="20" y="324" width="350" height="190" rx="27" fill="#20251d" />
      <text x="42" y="361" fill="#eef0e8" fontSize="15" fontWeight="700">Cash flow</text><text x="295" y="361" fill="#92998c" fontSize="12">6 months</text>
      <g stroke="#353b31" strokeWidth="1"><path d="M42 403h302M42 445h302M42 487h302" /></g>
      <path d="M42 466C80 465 82 417 116 430S165 473 199 433 246 388 275 411 313 382 344 372" fill="none" stroke={accent} strokeWidth="4" strokeLinecap="round" />
      <path d="M42 466C80 465 82 417 116 430S165 473 199 433 246 388 275 411 313 382 344 372V490H42Z" fill="url(#orbitFade)" opacity=".18" />
      <defs><linearGradient id="orbitFade" x1="0" y1="0" x2="0" y2="1"><stop stopColor={accent} /><stop offset="1" stopColor={accent} stopOpacity="0" /></linearGradient></defs>
      <circle cx="344" cy="372" r="7" fill="#20251d" stroke={accent} strokeWidth="4" />
      <text x="28" y="559" fill="#f5f6ef" fontSize="18" fontWeight="700">Recent activity</text><text x="309" y="559" fill={accent} fontSize="12">See all</text>
      {[['Field Notes', 'Today, 10:24', '- $18.40'], ['Northline Studio', 'Yesterday', '+ $2,400'], ['Public House', 'Mon, 18:42', '- $64.00']].map((row, i) => <g key={row[0]} transform={`translate(28 ${586 + i * 68})`}><rect width="44" height="44" rx="14" fill={i === 1 ? accent : '#292e26'} /><text x="14" y="28" fill={i === 1 ? '#151911' : '#eef0e8'} fontSize="15" fontWeight="700">{row[0][0]}</text><text x="58" y="18" fill="#f1f2eb" fontSize="14" fontWeight="700">{row[0]}</text><text x="58" y="37" fill="#858c80" fontSize="11">{row[1]}</text><text x="334" y="26" textAnchor="end" fill={i === 1 ? accent : '#f1f2eb'} fontSize="13" fontWeight="700">{row[2]}</text></g>)}
      <rect x="73" y="786" width="244" height="44" rx="22" fill="#252a22" /><circle cx="111" cy="808" r="6" fill={accent} /><circle cx="169" cy="808" r="6" fill="#6c7367" /><circle cx="227" cy="808" r="6" fill="#6c7367" /><circle cx="285" cy="808" r="6" fill="#6c7367" />
    </g>
  </>;
}

function Noma({ title, accent }: { title: string; accent: string }) {
  return <>
    <rect width="390" height="844" fill="#f3f0e7" /><StatusBar />
    <image href="/images/noma-coast.jpg" x="0" y="62" width="390" height="460" preserveAspectRatio="xMidYMid slice" />
    <rect x="0" y="62" width="390" height="460" fill="url(#nomaShade)" />
    <defs><linearGradient id="nomaShade" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#10261f" stopOpacity=".12" /><stop offset="1" stopColor="#10261f" stopOpacity=".72" /></linearGradient></defs>
    <g fontFamily={font}>
      <text x="28" y="112" fill="#fff" fontSize="25" fontWeight="700" letterSpacing="-1">{title}<tspan fill={accent}>.</tspan></text>
      <rect x="298" y="84" width="62" height="31" rx="15.5" fill="#ffffff25" stroke="#ffffff60" /><text x="329" y="104" textAnchor="middle" fill="#fff" fontSize="11" fontWeight="700">MENU</text>
      <text x="28" y="390" fill="#e9f0e7" fontSize="12" letterSpacing="2.2">36.712° N, 4.421° W</text>
      <text x="28" y="438" fill="#fff" fontSize="42" fontWeight="700" letterSpacing="-1.5">Take the</text><text x="28" y="480" fill="#fff" fontSize="42" fontWeight="700" letterSpacing="-1.5">long way home.</text>
      <text x="28" y="566" fill="#77796f" fontSize="11" fontWeight="700" letterSpacing="2">THE FIELD JOURNAL — 028</text>
      <text x="28" y="607" fill="#1e241e" fontSize="25" fontWeight="700">A slower coast</text>
      <text x="28" y="637" fill="#6b7067" fontSize="14">Salt air, small roads and nowhere</text><text x="28" y="658" fill="#6b7067" fontSize="14">particular to be by five.</text>
      <rect x="28" y="696" width="334" height="1" fill="#d1cfc4" />
      <text x="28" y="732" fill="#77796f" fontSize="11" letterSpacing="1.5">NEXT STORY</text><text x="28" y="766" fill="#1e241e" fontSize="18" fontWeight="700">Notes from the high desert</text><text x="340" y="766" textAnchor="end" fill="#1e241e" fontSize="25">↗</text>
      <rect x="144" y="814" width="102" height="5" rx="3" fill="#252b24" />
    </g>
  </>;
}

function Muse({ title, accent }: { title: string; accent: string }) {
  return <>
    <rect width="390" height="844" fill="#25172d" /><StatusBar dark />
    <defs><linearGradient id="museBg" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#ef8cbd" /><stop offset=".48" stopColor="#8a5dd6" /><stop offset="1" stopColor="#342453" /></linearGradient><radialGradient id="museDisc"><stop stopColor="#f7d6ea" /><stop offset=".15" stopColor="#3c224d" /><stop offset=".18" stopColor="#c47bb4" /><stop offset=".5" stopColor="#432956" /><stop offset="1" stopColor="#18111f" /></radialGradient></defs>
    <g fontFamily={font}>
      <text x="28" y="88" fill="#d4bfdc" fontSize="12" textAnchor="start">NOW PLAYING</text><text x="362" y="88" fill="#d4bfdc" fontSize="22" textAnchor="end">•••</text>
      <rect x="28" y="122" width="334" height="334" rx="30" fill="url(#museBg)" />
      <circle cx="195" cy="289" r="122" fill="url(#museDisc)" /><circle cx="195" cy="289" r="24" fill={accent} /><circle cx="195" cy="289" r="7" fill="#31203c" />
      <path d="M57 176c62 20 123-31 236-9M55 402c90-31 179 25 279-12" stroke="#fff" strokeOpacity=".23" fill="none" strokeWidth="2" />
      <text x="28" y="515" fill="#f9eaf7" fontSize="31" fontWeight="700" letterSpacing="-1">Soft Focus</text>
      <text x="28" y="546" fill="#bfa8ca" fontSize="16">Glasser Avenue — {title}</text>
      <path d="M28 588h334" stroke="#5b4167" strokeWidth="5" strokeLinecap="round" /><path d="M28 588h126" stroke={accent} strokeWidth="5" strokeLinecap="round" /><circle cx="154" cy="588" r="7" fill={accent} />
      <text x="28" y="614" fill="#a88db5" fontSize="11">1:42</text><text x="362" y="614" textAnchor="end" fill="#a88db5" fontSize="11">3:58</text>
      <g fill="#f7eaf6"><path d="M64 676l24-14v28zM84 662h4v28h-4zM302 662h4v28h-4zM304 676l24-14v28z" /><path d="M167 655l14 21-14 21zM209 655l-14 21 14 21z" /><rect x="183" y="651" width="25" height="50" rx="12" fill={accent} /><path d="M190 666v20M198 666v20" stroke="#2d1b36" strokeWidth="3" strokeLinecap="round" /></g>
      <rect x="28" y="747" width="334" height="52" rx="18" fill="#372440" /><circle cx="54" cy="773" r="12" fill={accent} /><text x="78" y="769" fill="#f6eaf5" fontSize="13" fontWeight="700">Up next: Daylight Reverbs</text><text x="78" y="787" fill="#a88db5" fontSize="11">The Night Fields</text>
    </g>
  </>;
}

function Pulse({ title, accent }: { title: string; accent: string }) {
  const bars = [72, 110, 86, 142, 126, 174, 152, 204, 188, 232, 216, 260];
  return <>
    <rect width="1440" height="900" fill="#f6f6f2" />
    <rect width="220" height="900" fill="#171a18" />
    <g fontFamily={font}>
      <circle cx="40" cy="48" r="13" fill={accent} /><path d="M34 48l5 5 8-11" stroke="#fff" strokeWidth="2.5" fill="none" />
      <text x="66" y="57" fill="#fff" fontSize="26" fontWeight="700">{title}</text>
      <text x="32" y="120" fill="#777e77" fontSize="11" letterSpacing="2">WORKSPACE</text>
      {['Overview', 'Analytics', 'Customers', 'Reports', 'Automations'].map((item, i) => <g key={item} transform={`translate(20 ${148 + i * 58})`}>{i === 1 && <rect width="180" height="42" rx="10" fill="#2b2f2b" />}<circle cx="18" cy="21" r="5" fill={i === 1 ? accent : '#697068'} /><text x="40" y="27" fill={i === 1 ? '#fff' : '#a1a7a0'} fontSize="14" fontWeight={i === 1 ? '700' : '400'}>{item}</text></g>)}
      <rect x="20" y="800" width="180" height="68" rx="13" fill="#242824" /><circle cx="48" cy="834" r="16" fill="#d6b69e" /><text x="76" y="830" fill="#fff" fontSize="12" fontWeight="700">Alex Morgan</text><text x="76" y="848" fill="#8e958d" fontSize="10">Studio team</text>
      <text x="268" y="61" fill="#8a8e87" fontSize="13">Analytics / Overview</text><text x="268" y="116" fill="#1b1e1b" fontSize="35" fontWeight="700" letterSpacing="-1">Good morning, Alex.</text><text x="268" y="145" fill="#7d817a" fontSize="14">Here’s what’s moving across your business.</text>
      <rect x="1212" y="84" width="176" height="46" rx="12" fill="#1b1e1b" /><text x="1300" y="112" textAnchor="middle" fill="#fff" fontSize="13" fontWeight="700">Download report</text>
      {[['Total revenue', '$128,430', '+12.5%'], ['Active customers', '8,942', '+8.2%'], ['Conversion', '4.82%', '+1.4%']].map((card, i) => <g key={card[0]} transform={`translate(${268 + i * 382} 190)`}><rect width="350" height="150" rx="18" fill="#fff" stroke="#e3e4de" /><text x="24" y="35" fill="#797e76" fontSize="13">{card[0]}</text><text x="24" y="85" fill="#1d201c" fontSize="34" fontWeight="700">{card[1]}</text><rect x="24" y="108" width="69" height="23" rx="11" fill="#eaf5df" /><text x="58" y="124" textAnchor="middle" fill="#47772f" fontSize="11" fontWeight="700">{card[2]}</text><path d="M258 112l18-20 15 8 32-39" fill="none" stroke={accent} strokeWidth="3" /><circle cx="323" cy="61" r="4" fill={accent} /></g>)}
      <rect x="268" y="372" width="732" height="422" rx="18" fill="#fff" stroke="#e3e4de" />
      <text x="294" y="415" fill="#1d201c" fontSize="17" fontWeight="700">Revenue performance</text><text x="294" y="439" fill="#8a8e87" fontSize="12">January — December 2026</text>
      <rect x="831" y="398" width="140" height="34" rx="9" fill="#f4f4ef" /><text x="901" y="420" textAnchor="middle" fill="#646a62" fontSize="11">Last 12 months⌄</text>
      <g stroke="#ecece7"><path d="M294 502h680M294 566h680M294 630h680M294 694h680" /></g>
      {bars.map((bar, i) => <g key={i}><rect x={310 + i * 55} y={718 - bar} width="28" height={bar} rx="6" fill={i === 11 ? accent : '#ded9ff'} /><text x={324 + i * 55} y="747" textAnchor="middle" fill="#92968f" fontSize="10">{['J','F','M','A','M','J','J','A','S','O','N','D'][i]}</text></g>)}
      <rect x="1032" y="372" width="356" height="422" rx="18" fill="#fff" stroke="#e3e4de" />
      <text x="1058" y="415" fill="#1d201c" fontSize="17" fontWeight="700">Top channels</text><text x="1058" y="439" fill="#8a8e87" fontSize="12">By total revenue</text>
      <circle cx="1210" cy="564" r="89" fill="none" stroke="#efefe9" strokeWidth="28" /><path d="M1210 475a89 89 0 0 1 78 132" fill="none" stroke={accent} strokeWidth="28" /><path d="M1288 607a89 89 0 0 1-142 32" fill="none" stroke="#b8e59b" strokeWidth="28" /><text x="1210" y="558" textAnchor="middle" fill="#1d201c" fontSize="28" fontWeight="700">$128k</text><text x="1210" y="581" textAnchor="middle" fill="#92968f" fontSize="11">total volume</text>
      <circle cx="1064" cy="704" r="5" fill={accent} /><text x="1080" y="709" fill="#666c64" fontSize="12">Organic search</text><text x="1358" y="709" textAnchor="end" fill="#1d201c" fontSize="12" fontWeight="700">48%</text><circle cx="1064" cy="740" r="5" fill="#b8e59b" /><text x="1080" y="745" fill="#666c64" fontSize="12">Direct</text><text x="1358" y="745" textAnchor="end" fill="#1d201c" fontSize="12" fontWeight="700">31%</text>
    </g>
  </>;
}

function Atelier({ title, accent }: { title: string; accent: string }) {
  return <>
    <rect width="1440" height="900" fill="#f2efe7" />
    <g fontFamily={font}>
      <text x="54" y="62" fill="#1d211b" fontSize="27" fontWeight="700" letterSpacing="-1">{title}<tspan fill="#77922c">.</tspan></text>
      <text x="520" y="59" fill="#555c51" fontSize="13">Objects</text><text x="610" y="59" fill="#555c51" fontSize="13">Collections</text><text x="724" y="59" fill="#555c51" fontSize="13">Our story</text><text x="823" y="59" fill="#555c51" fontSize="13">Journal</text>
      <rect x="1238" y="30" width="148" height="44" rx="22" fill="#1d211b" /><text x="1312" y="57" textAnchor="middle" fill="#fff" fontSize="12">Cart (0)</text>
      <image href="/images/atelier-chair.jpg" x="54" y="112" width="850" height="650" preserveAspectRatio="xMidYMid slice" />
      <rect x="54" y="700" width="850" height="62" fill="#1d211b" opacity=".78" /><text x="80" y="738" fill="#fff" fontSize="13" letterSpacing="1">COLLECTION 04 — QUIET FORMS</text>
      <text x="956" y="174" fill="#777b71" fontSize="11" letterSpacing="2">NEW / HAND-FINISHED</text>
      <text x="950" y="250" fill="#20241e" fontSize="64" fontWeight="700" letterSpacing="-3">Less, but</text><text x="950" y="316" fill="#20241e" fontSize="64" fontWeight="700" letterSpacing="-3">lovelier.</text>
      <text x="956" y="372" fill="#656b61" fontSize="16">Useful objects with a quiet presence.</text><text x="956" y="397" fill="#656b61" fontSize="16">Made slowly. Kept for a long time.</text>
      <rect x="956" y="448" width="208" height="54" rx="27" fill={accent} /><text x="1060" y="481" textAnchor="middle" fill="#263019" fontSize="13" fontWeight="700">Explore the collection ↗</text>
      <text x="956" y="596" fill="#777b71" fontSize="11" letterSpacing="2">FEATURED OBJECT</text><text x="956" y="640" fill="#20241e" fontSize="25" fontWeight="700">Lounge No. 04</text><text x="956" y="670" fill="#656b61" fontSize="14">Oak, natural linen / $1,280</text>
      <rect x="54" y="808" width="1332" height="1" fill="#d3d0c6" /><text x="54" y="852" fill="#6c7168" fontSize="12">Thoughtfully made in small batches</text><text x="720" y="852" textAnchor="middle" fill="#6c7168" fontSize="12">Free carbon-neutral delivery</text><text x="1386" y="852" textAnchor="end" fill="#6c7168" fontSize="12">Five-year care promise</text>
    </g>
  </>;
}

export default function SampleArtwork({ sample, title, accent }: { sample: SampleName; title: string; accent: string }) {
  const isDesktop = sample === 'pulse' || sample === 'atelier';
  return <svg x="0" y="0" width="100%" height="100%" viewBox={isDesktop ? '0 0 1440 900' : '0 0 390 844'} preserveAspectRatio="xMidYMid slice" overflow="hidden">
    {sample === 'orbit' && <Orbit title={title} accent={accent} />}
    {sample === 'noma' && <Noma title={title} accent={accent} />}
    {sample === 'muse' && <Muse title={title} accent={accent} />}
    {sample === 'pulse' && <Pulse title={title} accent={accent} />}
    {sample === 'atelier' && <Atelier title={title} accent={accent} />}
  </svg>;
}
