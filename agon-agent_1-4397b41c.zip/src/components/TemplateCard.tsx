import { ArrowUpRight } from 'lucide-react';
import { motion } from 'framer-motion';
import type { Template } from '../lib/api';
import { deviceLabels, normalizeConfig } from '../lib/config';
import MockupCanvas from './MockupCanvas';

export default function TemplateCard({ template, onUse, index = 0 }: { template: Template; onUse: (template: Template) => void; index?: number }) {
  return <motion.article initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(index * 0.045, 0.3) }} className="group overflow-hidden rounded-[22px] border border-[#dddeda] bg-[#fbfbf7]">
    <button onClick={() => onUse(template)} className="relative block w-full overflow-hidden bg-[#e8e9e2] text-left" aria-label={`Use ${template.name} template`}>
      <div className="aspect-[4/3] p-5 transition-transform duration-500 group-hover:scale-[1.025]">
        <MockupCanvas config={normalizeConfig(template.config)} className="h-full w-full overflow-hidden rounded-[12px] shadow-[0_16px_35px_rgba(30,35,25,.12)]" label={`${template.name} mockup template`} />
      </div>
      <span className="absolute right-4 top-4 grid h-9 w-9 translate-y-2 place-items-center rounded-full bg-[#1e211c] text-white opacity-0 transition-all group-hover:translate-y-0 group-hover:opacity-100"><ArrowUpRight size={17} /></span>
    </button>
    <div className="flex items-start justify-between gap-4 border-t border-[#e2e3dd] p-5">
      <div><p className="mb-1 text-[10px] font-bold uppercase tracking-[0.16em] text-[#878c82]">{template.category} · {deviceLabels[template.device]}</p><h3 className="text-[16px] font-bold tracking-[-0.025em] text-[#20231e]">{template.name}</h3><p className="mt-1.5 line-clamp-2 text-[12px] leading-5 text-[#777c72]">{template.description}</p></div>
      <button onClick={() => onUse(template)} className="shrink-0 rounded-full border border-[#d8dad1] px-3 py-1.5 text-[11px] font-bold text-[#383d34] transition-colors hover:bg-[#e9f7c9]">Use</button>
    </div>
  </motion.article>;
}
