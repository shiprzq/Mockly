import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { ArrowUpRight, Menu, X } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import Logo from './Logo';

const links = [
  { to: '/studio', label: 'Studio' },
  { to: '/gallery', label: 'Gallery' },
  { to: '/projects', label: 'My projects' },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="relative z-40 border-b border-[#dcded4] bg-[#f7f7f2]/90 backdrop-blur-xl">
      <div className="mx-auto flex h-[72px] max-w-[1500px] items-center justify-between px-5 sm:px-8">
        <Logo />
        <nav className="hidden items-center gap-8 md:flex" aria-label="Main navigation">
          {links.map((link) => (
            <NavLink key={link.to} to={link.to} className={({ isActive }) => `text-[13px] font-semibold transition-colors ${isActive ? 'text-[#1b1e19]' : 'text-[#6b7067] hover:text-[#1b1e19]'}`}>
              {link.label}
            </NavLink>
          ))}
          <a href="/#how-it-works" className="text-[13px] font-semibold text-[#6b7067] transition-colors hover:text-[#1b1e19]">How it works</a>
        </nav>
        <div className="flex items-center gap-2">
          <Link to="/studio" className="hidden items-center gap-2 rounded-full bg-[#1d201b] px-5 py-2.5 text-[13px] font-semibold text-white transition-all hover:-translate-y-0.5 hover:bg-[#34392f] sm:inline-flex">
            Create a mockup <ArrowUpRight size={15} />
          </Link>
          <button onClick={() => setOpen(!open)} className="grid h-10 w-10 place-items-center rounded-full border border-[#dcded4] md:hidden" aria-label="Toggle navigation">
            {open ? <X size={19} /> : <Menu size={19} />}
          </button>
        </div>
      </div>
      <AnimatePresence>
        {open && (
          <motion.nav initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden border-t border-[#dcded4] bg-[#f7f7f2] md:hidden">
            <div className="flex flex-col px-5 py-4">
              {links.map((link) => <Link onClick={() => setOpen(false)} key={link.to} to={link.to} className="border-b border-[#e6e7e0] py-4 text-sm font-semibold">{link.label}</Link>)}
              <a href="/#how-it-works" onClick={() => setOpen(false)} className="py-4 text-sm font-semibold">How it works</a>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
