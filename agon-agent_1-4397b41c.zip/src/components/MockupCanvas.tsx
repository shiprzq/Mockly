import { forwardRef, useId } from 'react';
import type { PointerEvent as ReactPointerEvent } from 'react';
import type { DeviceType, MockupConfig } from '../lib/config';
import SampleArtwork from './SampleArtwork';

interface DeviceSpec {
  width: number;
  height: number;
  screen: { x: number; y: number; width: number; height: number; radius: number };
}

const specs: Record<DeviceType, DeviceSpec> = {
  phone: { width: 430, height: 880, screen: { x: 26, y: 24, width: 378, height: 832, radius: 54 } },
  tablet: { width: 700, height: 960, screen: { x: 38, y: 42, width: 624, height: 876, radius: 27 } },
  laptop: { width: 1200, height: 790, screen: { x: 94, y: 48, width: 1012, height: 612, radius: 12 } },
  browser: { width: 1120, height: 760, screen: { x: 2, y: 64, width: 1116, height: 694, radius: 0 } },
  watch: { width: 400, height: 520, screen: { x: 74, y: 124, width: 252, height: 272, radius: 58 } },
};

const finishes = {
  graphite: { edge: '#111311', mid: '#353934', light: '#777d74' },
  silver: { edge: '#7f8581', mid: '#d8dbd7', light: '#f7f8f4' },
  gold: { edge: '#88745a', mid: '#d6c2a2', light: '#fff1d4' },
  blue: { edge: '#405769', mid: '#8ba7b9', light: '#d5e8f0' },
  coral: { edge: '#834333', mid: '#ce7863', light: '#ffc1a9' },
};

function DeviceFrame({ device, uid }: { device: DeviceType; uid: string }) {
  const finishId = `finish-${uid}`;
  if (device === 'phone') return <g>
    <rect x="2" y="2" width="426" height="876" rx="74" fill="#080a08" opacity=".4" />
    <rect x="0" y="0" width="430" height="880" rx="74" fill={`url(#${finishId})`} stroke="#090b09" strokeWidth="2" />
    <rect x="9" y="9" width="412" height="862" rx="66" fill="#090b09" stroke="#838980" strokeOpacity=".45" />
    <rect x="21" y="19" width="388" height="842" rx="58" fill="#050605" />
    <rect x="-3" y="164" width="5" height="55" rx="2" fill="#292d28" /><rect x="-3" y="243" width="5" height="88" rx="2" fill="#292d28" /><rect x="428" y="235" width="5" height="132" rx="2" fill="#292d28" />
  </g>;
  if (device === 'tablet') return <g>
    <rect width="700" height="960" rx="52" fill={`url(#${finishId})`} stroke="#222620" strokeWidth="2" />
    <rect x="14" y="14" width="672" height="932" rx="42" fill="#10120f" stroke="#f5fff0" strokeOpacity=".22" />
    <rect x="30" y="34" width="640" height="892" rx="32" fill="#050605" />
    <circle cx="350" cy="24" r="5" fill="#252c2c" /><circle cx="350" cy="24" r="2" fill="#455b64" />
    <rect x="688" y="128" width="5" height="76" rx="2" fill="#454a44" />
  </g>;
  if (device === 'laptop') return <g>
    <rect x="70" y="20" width="1060" height="680" rx="31" fill={`url(#${finishId})`} stroke="#292d28" strokeWidth="2" />
    <rect x="82" y="32" width="1036" height="656" rx="23" fill="#080a08" />
    <circle cx="600" cy="39" r="3" fill="#3e4948" />
    <path d="M46 698h1108l32 38c13 16 1 35-22 35H36c-23 0-35-19-22-35z" fill={`url(#${finishId})`} stroke="#777c75" strokeWidth="1.5" />
    <path d="M14 736h1172l-12 12c-5 5-13 8-23 8H49c-10 0-18-3-23-8z" fill="#7b817a" opacity=".55" />
    <path d="M516 698h168l14 20c2 5-3 10-10 10H512c-7 0-12-5-10-10z" fill="#8e938d" opacity=".75" />
    <path d="M54 771h1092" stroke="#1c211d" strokeOpacity=".35" strokeWidth="3" strokeLinecap="round" />
  </g>;
  if (device === 'browser') return <g>
    <rect width="1120" height="760" rx="26" fill="#f5f5f2" stroke="#3a3d38" strokeOpacity=".35" strokeWidth="2" />
    <path d="M0 26A26 26 0 0 1 26 0h1068a26 26 0 0 1 26 26v40H0z" fill="#e9eae5" />
    <path d="M0 65h1120" stroke="#cdd0c8" />
    <circle cx="30" cy="32" r="6" fill="#ff7b6c" /><circle cx="51" cy="32" r="6" fill="#f3c854" /><circle cx="72" cy="32" r="6" fill="#77c787" />
    <rect x="112" y="16" width="36" height="32" rx="8" fill="#dde0d8" /><text x="130" y="38" textAnchor="middle" fill="#7b8077" fontFamily="Arial" fontSize="18">‹</text><text x="165" y="38" textAnchor="middle" fill="#9da199" fontFamily="Arial" fontSize="18">›</text>
    <rect x="205" y="13" width="710" height="38" rx="12" fill="#f8f9f5" stroke="#d8dad3" /><circle cx="229" cy="32" r="5" fill="none" stroke="#8d9389" /><text x="560" y="37" textAnchor="middle" fill="#737970" fontFamily="Arial" fontSize="13">your-next-big-thing.com</text>
    <path d="M1070 24v16M1062 32h16" stroke="#8b9188" strokeWidth="1.5" strokeLinecap="round" />
  </g>;
  return <g>
    <path d="M126 0h148l18 133H108z" fill={`url(#${finishId})`} /><path d="M108 387h184l-18 133H126z" fill={`url(#${finishId})`} />
    {[18, 44, 70, 424, 450, 476].map((y) => <path key={y} d={`M132 ${y}h136`} stroke="#151915" strokeOpacity=".17" strokeWidth="2" />)}
    <rect x="52" y="102" width="296" height="316" rx="82" fill={`url(#${finishId})`} stroke="#1f241f" strokeWidth="2" />
    <rect x="63" y="113" width="274" height="294" rx="70" fill="#0a0c0a" stroke="#e8eee5" strokeOpacity=".25" />
    <rect x="346" y="178" width="16" height="66" rx="8" fill="#626960" stroke="#222722" /><rect x="346" y="269" width="10" height="44" rx="5" fill="#555b53" />
  </g>;
}

interface Props {
  config: MockupConfig;
  className?: string;
  interactive?: boolean;
  onDevicePointerDown?: (event: ReactPointerEvent<SVGGElement>) => void;
  onPointerMove?: (event: ReactPointerEvent<SVGSVGElement>) => void;
  onPointerUp?: (event: ReactPointerEvent<SVGSVGElement>) => void;
  onPointerCancel?: (event: ReactPointerEvent<SVGSVGElement>) => void;
  label?: string;
}

const MockupCanvas = forwardRef<SVGSVGElement, Props>(function MockupCanvas({ config, className = '', interactive = false, onDevicePointerDown, onPointerMove, onPointerUp, onPointerCancel, label = 'Device mockup preview' }, ref) {
  const uid = useId().replace(/:/g, '');
  const spec = specs[config.device] || specs.phone;
  const { screen } = spec;
  const finish = finishes[config.finish] || finishes.graphite;
  const gradientAngle = (config.background.angle * Math.PI) / 180;
  const gx = Math.cos(gradientAngle) * 50;
  const gy = Math.sin(gradientAngle) * 50;
  const captionX = config.caption.align === 'center' ? config.canvasWidth / 2 : 72;
  const shortText = (text: string, max: number) => text.length > max ? `${text.slice(0, max - 1)}…` : text;
  const cx = screen.x + screen.width / 2;
  const cy = screen.y + screen.height / 2;

  return <svg
    ref={ref}
    viewBox={`0 0 ${config.canvasWidth} ${config.canvasHeight}`}
    className={className}
    role="img"
    aria-label={label}
    xmlns="http://www.w3.org/2000/svg"
    onPointerMove={onPointerMove}
    onPointerUp={onPointerUp}
    onPointerCancel={onPointerCancel}
    style={{ display: 'block', width: '100%', height: 'auto', touchAction: interactive ? 'none' : 'auto' }}
  >
    <defs>
      <linearGradient id={`bg-${uid}`} x1={`${50 - gx}%`} y1={`${50 - gy}%`} x2={`${50 + gx}%`} y2={`${50 + gy}%`}><stop stopColor={config.background.from} /><stop offset="1" stopColor={config.background.to} /></linearGradient>
      <linearGradient id={`finish-${uid}`} x1="0" y1="0" x2="1" y2="1"><stop stopColor={finish.light} /><stop offset=".24" stopColor={finish.mid} /><stop offset=".7" stopColor={finish.edge} /><stop offset="1" stopColor={finish.mid} /></linearGradient>
      <linearGradient id={`glare-${uid}`} x1="0" y1="0" x2="1" y2="1"><stop stopColor="#fff" stopOpacity=".3" /><stop offset=".42" stopColor="#fff" stopOpacity=".03" /><stop offset="1" stopColor="#fff" stopOpacity="0" /></linearGradient>
      <pattern id={`dots-${uid}`} width="34" height="34" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="1.5" fill="#182016" opacity=".14" /></pattern>
      <pattern id={`grid-${uid}`} width="64" height="64" patternUnits="userSpaceOnUse"><path d="M64 0H0V64" fill="none" stroke="#182016" strokeOpacity=".1" strokeWidth="1" /></pattern>
      <filter id={`shadow-${uid}`} x="-60%" y="-60%" width="220%" height="240%"><feDropShadow dx="0" dy={18 + config.shadow * 0.32} stdDeviation={12 + config.shadow * 0.3} floodColor="#11150e" floodOpacity={config.shadow / 210} /></filter>
      <filter id={`noise-${uid}`} x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".72" numOctaves="3" stitchTiles="stitch" /><feColorMatrix type="saturate" values="0" /></filter>
      <clipPath id={`screen-${uid}`}><rect x={screen.x} y={screen.y} width={screen.width} height={screen.height} rx={screen.radius} /></clipPath>
      <clipPath id={`outer-${uid}`}><rect width={spec.width} height={spec.height} rx={config.device === 'browser' ? 26 : 0} /></clipPath>
    </defs>

    {config.background.type !== 'transparent' && <rect width={config.canvasWidth} height={config.canvasHeight} fill={config.background.type === 'gradient' ? `url(#bg-${uid})` : config.background.from} />}
    {config.background.type !== 'transparent' && config.background.pattern !== 'none' && <rect width={config.canvasWidth} height={config.canvasHeight} fill={`url(#${config.background.pattern}-${uid})`} />}

    <g
      transform={`translate(${config.canvasWidth / 2 + config.x} ${config.canvasHeight / 2 + config.y}) rotate(${config.rotation}) scale(${config.scale}) translate(${-spec.width / 2} ${-spec.height / 2})`}
      filter={config.shadow > 0 ? `url(#shadow-${uid})` : undefined}
      onPointerDown={interactive ? onDevicePointerDown : undefined}
      style={{ cursor: interactive ? 'grab' : undefined }}
    >
      <g clipPath={config.device === 'browser' ? `url(#outer-${uid})` : undefined}>
        <DeviceFrame device={config.device} uid={uid} />
        <g clipPath={`url(#screen-${uid})`}>
          <rect x={screen.x} y={screen.y} width={screen.width} height={screen.height} fill={config.screen.mode === 'sample' ? '#f4f4ef' : '#191c19'} />
          {config.screen.mode === 'sample' ? (
            <svg x={screen.x} y={screen.y} width={screen.width} height={screen.height} viewBox={(config.screen.sample === 'pulse' || config.screen.sample === 'atelier') ? '0 0 1440 900' : '0 0 390 844'} preserveAspectRatio="xMidYMid slice" overflow="hidden">
              <SampleArtwork sample={config.screen.sample} title={config.screen.title} accent={config.screen.accent} />
            </svg>
          ) : config.screen.url ? (
            <g transform={`translate(${cx + config.screen.panX} ${cy + config.screen.panY}) scale(${config.screen.zoom}) translate(${-cx} ${-cy})`}>
              <image href={config.screen.url} x={screen.x} y={screen.y} width={screen.width} height={screen.height} preserveAspectRatio={config.screen.fit === 'cover' ? 'xMidYMid slice' : 'xMidYMid meet'} />
            </g>
          ) : <g fontFamily="Arial, sans-serif" textAnchor="middle"><text x={cx} y={cy - 8} fill="#9da498" fontSize="22">Your screenshot</text><text x={cx} y={cy + 22} fill="#656c61" fontSize="14">Upload an image to fill this screen</text></g>}
          {config.glare && <path d={`M${screen.x - 40} ${screen.y}h${screen.width * 0.72}l${-screen.width * 0.55} ${screen.height}h${-screen.width * 0.4}z`} fill={`url(#glare-${uid})`} pointerEvents="none" />}
        </g>
      </g>
      {config.device === 'phone' && <g><rect x="151" y="40" width="128" height="35" rx="18" fill="#050605" /><circle cx="257" cy="57" r="5" fill="#121b1b" /><rect x="175" y="78" width="80" height="4" rx="2" fill="#fff" opacity=".12" /></g>}
      {config.device === 'watch' && <rect x="176" y="368" width="48" height="5" rx="2.5" fill="#fff" opacity=".45" />}
      {interactive && <rect data-export-hide="true" x="-8" y="-8" width={spec.width + 16} height={spec.height + 16} rx="30" fill="none" stroke="#ffffff" strokeOpacity=".5" strokeWidth="2" strokeDasharray="10 10" pointerEvents="none" />}
    </g>

    {config.caption.show && <g fontFamily="Arial, Helvetica, sans-serif" textAnchor={config.caption.align === 'center' ? 'middle' : 'start'} fill={config.caption.color}>
      <text x={captionX} y={config.canvasHeight - 86} fontSize={Math.max(24, config.canvasWidth / 34)} fontWeight="700" letterSpacing="-1">{shortText(config.caption.title, 60)}</text>
      <text x={captionX} y={config.canvasHeight - 46} fontSize={Math.max(14, config.canvasWidth / 66)} opacity=".7">{shortText(config.caption.subtitle, 84)}</text>
    </g>}
    {config.grain && config.background.type !== 'transparent' && <rect width={config.canvasWidth} height={config.canvasHeight} filter={`url(#noise-${uid})`} opacity=".055" pointerEvents="none" style={{ mixBlendMode: 'soft-light' }} />}
  </svg>;
});

export default MockupCanvas;
