import type { DeviceType, MockupConfig } from './config';

export interface Project {
  id: string;
  owner_key: string;
  name: string;
  device: DeviceType;
  config: MockupConfig;
  screenshot_url: string | null;
  is_shared: boolean;
  created_at: string;
  updated_at: string;
}

export interface Template {
  id: number;
  slug: string;
  name: string;
  category: string;
  description: string;
  device: DeviceType;
  config: MockupConfig;
  accent: string;
  featured: boolean;
  created_at: string;
}

export interface Asset {
  id: string;
  owner_key: string;
  name: string;
  url: string;
  path: string;
  content_type: string;
  width: number | null;
  height: number | null;
  created_at: string;
}

export function getOwnerKey() {
  const key = 'mockly:owner';
  let value = localStorage.getItem(key);
  if (!value) {
    value = crypto.randomUUID();
    localStorage.setItem(key, value);
  }
  return value;
}

export async function apiRequest<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
  return data as T;
}

export function saveDraft(config: MockupConfig, name: string, projectId: string | null) {
  localStorage.setItem('mockly:draft', JSON.stringify({ config, name, projectId }));
}

export function readDraft(): { config: MockupConfig; name: string; projectId: string | null } | null {
  try {
    const raw = localStorage.getItem('mockly:draft');
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function stageTemplate(config: MockupConfig, name: string) {
  saveDraft(config, name, null);
}

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1]);
    reader.onerror = () => reject(new Error('Could not read that file.'));
    reader.readAsDataURL(file);
  });
}
