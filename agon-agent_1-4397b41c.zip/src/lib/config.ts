export type DeviceType = 'phone' | 'tablet' | 'laptop' | 'browser' | 'watch';
export type SampleName = 'orbit' | 'noma' | 'muse' | 'pulse' | 'atelier';

export interface MockupConfig {
  canvasWidth: number;
  canvasHeight: number;
  background: {
    type: 'gradient' | 'solid' | 'transparent';
    from: string;
    to: string;
    angle: number;
    pattern: 'none' | 'dots' | 'grid';
  };
  device: DeviceType;
  finish: 'graphite' | 'silver' | 'gold' | 'blue' | 'coral';
  scale: number;
  rotation: number;
  x: number;
  y: number;
  shadow: number;
  glare: boolean;
  grain: boolean;
  screen: {
    mode: 'sample' | 'image';
    sample: SampleName;
    title: string;
    accent: string;
    url: string;
    fit: 'cover' | 'contain';
    zoom: number;
    panX: number;
    panY: number;
  };
  caption: {
    show: boolean;
    title: string;
    subtitle: string;
    align: 'left' | 'center';
    color: string;
  };
}

export const defaultConfig = (): MockupConfig => ({
  canvasWidth: 1200,
  canvasHeight: 1200,
  background: { type: 'gradient', from: '#e9ffad', to: '#b7e6c1', angle: 135, pattern: 'dots' },
  device: 'phone',
  finish: 'graphite',
  scale: 0.88,
  rotation: -6,
  x: 0,
  y: -12,
  shadow: 62,
  glare: true,
  grain: true,
  screen: {
    mode: 'sample', sample: 'orbit', title: 'Orbit', accent: '#d7ff6a', url: '',
    fit: 'cover', zoom: 1, panX: 0, panY: 0,
  },
  caption: { show: false, title: 'Orbit — money in balance', subtitle: 'A calmer way to see the whole picture.', align: 'center', color: '#182018' },
});

export function normalizeConfig(input?: Partial<MockupConfig> | null): MockupConfig {
  const base = defaultConfig();
  if (!input) return base;
  return {
    ...base,
    ...input,
    background: { ...base.background, ...(input.background || {}) },
    screen: { ...base.screen, ...(input.screen || {}) },
    caption: { ...base.caption, ...(input.caption || {}) },
  };
}

export const canvasPresets = [
  { id: 'square', label: 'Square', detail: '1:1', width: 1200, height: 1200 },
  { id: 'portrait', label: 'Portrait', detail: '4:5', width: 1200, height: 1500 },
  { id: 'landscape', label: 'Landscape', detail: '16:9', width: 1600, height: 900 },
  { id: 'story', label: 'Story', detail: '9:16', width: 1080, height: 1920 },
  { id: 'wide', label: 'Classic', detail: '3:2', width: 1500, height: 1000 },
];

export const backgroundPresets = [
  { name: 'Citron', from: '#efffba', to: '#b9e8c6' },
  { name: 'Lilac', from: '#e8ddff', to: '#b8abef' },
  { name: 'Peach', from: '#ffe0c7', to: '#f4a48f' },
  { name: 'Mist', from: '#eef2ef', to: '#c8d4d2' },
  { name: 'Night', from: '#282b35', to: '#101114' },
  { name: 'Sky', from: '#d9efff', to: '#91bfea' },
  { name: 'Blush', from: '#fff0ed', to: '#edc4d4' },
  { name: 'Paper', from: '#f4f1e8', to: '#d9d3c4' },
];

export const sampleDefinitions: Array<{
  id: SampleName;
  name: string;
  layout: 'mobile' | 'desktop';
  title: string;
  accent: string;
  description: string;
}> = [
  { id: 'orbit', name: 'Orbit', layout: 'mobile', title: 'Orbit', accent: '#d7ff6a', description: 'A focused finance dashboard' },
  { id: 'noma', name: 'Noma', layout: 'mobile', title: 'Noma', accent: '#f0ffdf', description: 'An editorial travel journal' },
  { id: 'muse', name: 'Muse', layout: 'mobile', title: 'Muse', accent: '#ffb4db', description: 'A rich, immersive music player' },
  { id: 'pulse', name: 'Pulse', layout: 'desktop', title: 'Pulse', accent: '#7557ff', description: 'A crisp analytics workspace' },
  { id: 'atelier', name: 'Atelier', layout: 'desktop', title: 'Atelier', accent: '#d5ff63', description: 'A refined objects storefront' },
];

export const deviceLabels: Record<DeviceType, string> = {
  phone: 'Phone', tablet: 'Tablet', laptop: 'Laptop', browser: 'Browser', watch: 'Watch',
};

export function getCanvasPreset(config: MockupConfig) {
  return canvasPresets.find((preset) => preset.width === config.canvasWidth && preset.height === config.canvasHeight)?.id || 'custom';
}
