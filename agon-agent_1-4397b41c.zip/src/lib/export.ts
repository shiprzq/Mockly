import type { MockupConfig } from './config';

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('Could not prepare an image for export.'));
    reader.readAsDataURL(blob);
  });
}

async function prepareSvg(svg: SVGSVGElement, scale: number) {
  const clone = svg.cloneNode(true) as SVGSVGElement;
  clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
  clone.setAttribute('xmlns:xlink', 'http://www.w3.org/1999/xlink');
  const width = Number(svg.getAttribute('viewBox')?.split(' ')[2] || 1200);
  const height = Number(svg.getAttribute('viewBox')?.split(' ')[3] || 1200);
  clone.setAttribute('width', String(width * scale));
  clone.setAttribute('height', String(height * scale));
  clone.removeAttribute('style');
  clone.querySelectorAll('[data-export-hide="true"]').forEach((node) => node.remove());

  const images = Array.from(clone.querySelectorAll('image'));
  for (const image of images) {
    const href = image.getAttribute('href') || image.getAttribute('xlink:href');
    if (!href || href.startsWith('data:')) continue;
    try {
      const absolute = new URL(href, window.location.origin).href;
      const response = await fetch(absolute, { mode: 'cors' });
      if (!response.ok) throw new Error('Image request failed');
      const dataUrl = await blobToDataUrl(await response.blob());
      image.setAttribute('href', dataUrl);
      image.removeAttribute('xlink:href');
    } catch {
      throw new Error('An image host blocked the export. Upload the screenshot to Mockly and try again.');
    }
  }
  return { source: new XMLSerializer().serializeToString(clone), width, height };
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function safeName(name: string) {
  return name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'mockly-scene';
}

export async function exportMockup(
  svg: SVGSVGElement,
  config: MockupConfig,
  format: 'png' | 'svg',
  scale: number,
  name: string,
) {
  const { source, width, height } = await prepareSvg(svg, scale);
  const svgBlob = new Blob([source], { type: 'image/svg+xml;charset=utf-8' });
  if (format === 'svg') {
    downloadBlob(svgBlob, `${safeName(name)}.svg`);
    return;
  }

  const url = URL.createObjectURL(svgBlob);
  try {
    const image = new Image();
    await new Promise<void>((resolve, reject) => {
      image.onload = () => resolve();
      image.onerror = () => reject(new Error('The scene could not be rasterized. Try SVG export instead.'));
      image.src = url;
    });
    const canvas = document.createElement('canvas');
    canvas.width = width * scale;
    canvas.height = height * scale;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Canvas export is not available in this browser.');
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/png'));
    if (!blob) throw new Error('The PNG could not be created. Please try again.');
    downloadBlob(blob, `${safeName(name)}@${scale}x.png`);
  } finally {
    URL.revokeObjectURL(url);
  }
}
