import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowDown, ArrowRight, ArrowUpRight, Check, Download, Layers3, MousePointer2, MoveUpRight, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import Header from '../components/Header';
import Logo from '../components/Logo';
import MockupCanvas from '../components/MockupCanvas';
import TemplateCard from '../components/TemplateCard';
import { apiRequest, stageTemplate, type Template } from '../lib/api';
import { defaultConfig } from '../lib/config';

export default function LandingPage() {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [templateError, setTemplateError] = useState('');
  const navigate = useNavigate();
  const heroConfig = { ...defaultConfig(), caption: { ...defaultConfig().caption, show: true, title: 'Orbit — money in balance', subtitle: 'Product mockup / 01', align: 'center' as const } };
  const browserConfig = { ...defaultConfig(), device: 'browser' as const, canvasWidth: 1400, canvasHeight: 980, scale: 0.88, rotation: 0, x: 0, y: 20, background: { ...defaultConfig().background, from: '#e6ddff', to: '#bcaef2', pattern: 'none' as const }, screen: { ...defaultConfig().screen, sample: 'pulse' as const, title: 'Pulse', accent: '#7557ff' }, grain: true };

  useEffect(() => {
    apiRequest<Template[]>('/api/templates?featured=true&limit=3').then(setTemplates).catch((error) => setTemplateError(error.message || 'The gallery could not be loaded.')).finally(() => setLoading(false));
    if (window.location.hash) setTimeout(() => document.querySelector(window.location.hash)?.scrollIntoView({ behavior: 'smooth' }), 100);
  }, []);

  const useTemplate = (template: Template) => {
    stageTemplate(template.config, template.name);
    navigate('/studio');
  };

  return <div className="min-h-screen bg-[#f7f7f2] text-[#20231e]">
    <Header />
    <main>
      <section className="relative mx-auto grid max-w-[1500px] items-center gap-12 overflow-hidden px-5 pb-16 pt-12 sm:px-8 lg:grid-cols-[.88fr_1.12fr] lg:gap-10 lg:pb-20 lg:pt-16">
        <div className="relative z-10 max-w-[650px]">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mb-7 inline-flex items-center gap-2 rounded-full border border-[#d9dcd1] bg-white/60 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.16em] text-[#5d6558]"><Sparkles size={12} className="text-[#829c3d]" /> Your work deserves a better frame</motion.div>
          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.06 }} className="text-[clamp(48px,6.1vw,88px)] font-semibold leading-[.96] tracking-[-0.067em]">Make it look<br /><span className="font-serif font-normal italic tracking-[-0.045em] text-[#61733c]">already shipped.</span></motion.h1>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.12 }} className="mt-7 max-w-[490px] text-[16px] leading-7 text-[#686e64] sm:text-[18px]">Beautiful device mockups for websites, apps and screenshots. Drop in your work, find the light, and export a scene worth sharing.</motion.p>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }} className="mt-8 flex flex-wrap items-center gap-3">
            <Link to="/studio" className="group inline-flex items-center gap-3 rounded-full bg-[#1d201b] px-6 py-3.5 text-[14px] font-semibold text-white shadow-[0_10px_24px_rgba(25,30,20,.15)] transition-all hover:-translate-y-0.5">Start creating — it’s free <ArrowUpRight size={17} className="transition-transform group-hover:rotate-45" /></Link>
            <Link to="/gallery" className="inline-flex items-center gap-2 rounded-full border border-[#d4d7cb] px-6 py-3.5 text-[14px] font-semibold transition-colors hover:bg-white">Explore scenes <ArrowRight size={16} /></Link>
          </motion.div>
          <div className="mt-9 flex flex-wrap gap-x-5 gap-y-2 text-[11px] font-medium text-[#73796e]">{['No watermark', 'PNG + SVG export', 'No sign-up needed'].map((item) => <span key={item} className="inline-flex items-center gap-1.5"><Check size={13} className="text-[#6d8734]" />{item}</span>)}</div>
        </div>
        <motion.div initial={{ opacity: 0, scale: 0.96, rotate: 1 }} animate={{ opacity: 1, scale: 1, rotate: 0 }} transition={{ duration: 0.65, ease: [0.2, 0.8, 0.2, 1] }} className="relative mx-auto w-full max-w-[720px]">
          <div className="absolute -left-3 top-12 z-10 hidden items-center gap-2 rounded-full border border-white/70 bg-white/80 px-3 py-2 text-[10px] font-bold shadow-lg backdrop-blur-md sm:flex"><MousePointer2 size={13} fill="#d5ff63" /> DRAG TO COMPOSE</div>
          <MockupCanvas config={heroConfig} className="overflow-hidden rounded-[28px] shadow-[0_30px_70px_rgba(43,54,28,.16)]" label="Phone mockup with the Orbit finance app" />
          <div className="absolute -bottom-4 right-5 rounded-2xl border border-white/80 bg-[#f9faf5]/90 px-4 py-3 shadow-xl backdrop-blur-xl"><p className="text-[9px] font-bold uppercase tracking-[0.17em] text-[#838a7c]">Made in Mockly</p><p className="mt-1 text-[12px] font-bold">Ready for the spotlight ↗</p></div>
        </motion.div>
        <a href="#possibilities" className="absolute bottom-4 left-8 hidden items-center gap-2 text-[10px] font-bold uppercase tracking-[.15em] text-[#8a9083] lg:inline-flex"><ArrowDown size={13} /> See what’s possible</a>
      </section>

      <section id="possibilities" className="border-y border-[#dcdfd4] bg-[#eeefe8] px-5 py-20 sm:px-8 lg:py-28">
        <div className="mx-auto max-w-[1380px]">
          <div className="mb-12 flex flex-col justify-between gap-6 md:flex-row md:items-end"><div><p className="mb-4 text-[10px] font-bold uppercase tracking-[0.2em] text-[#7b8373]">Small details. Big difference.</p><h2 className="max-w-[690px] text-[clamp(34px,4vw,58px)] font-semibold leading-[1.03] tracking-[-0.055em]">A whole photo studio,<br /><span className="font-serif font-normal italic text-[#71834d]">without the studio.</span></h2></div><p className="max-w-[360px] text-[14px] leading-6 text-[#72786e]">From a quick launch post to a polished case study, compose exactly the scene you have in mind.</p></div>
          <div className="grid gap-5 lg:grid-cols-[1.35fr_.65fr]">
            <div className="overflow-hidden rounded-[26px] border border-[#d8dbd0] bg-[#e2d9f5]">
              <MockupCanvas config={browserConfig} label="Browser mockup with Pulse analytics" />
              <div className="flex items-center justify-between bg-[#f9f9f5] px-6 py-5"><div><p className="text-[10px] font-bold uppercase tracking-[.15em] text-[#8b9085]">Built for your big ideas</p><h3 className="mt-1 text-[20px] font-bold tracking-[-.03em]">Frames that feel like the real thing.</h3></div><Layers3 className="text-[#8a6de0]" /></div>
            </div>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-1">
              <div className="flex min-h-[250px] flex-col justify-between rounded-[26px] bg-[#d9ff68] p-7"><div className="grid h-11 w-11 place-items-center rounded-2xl bg-[#20241b] text-[#d9ff68]"><MousePointer2 size={20} /></div><div><h3 className="text-[24px] font-bold tracking-[-.04em]">Compose, don’t compromise.</h3><p className="mt-3 text-[13px] leading-6 text-[#53602f]">Drag, rotate, crop and tune every shadow. Your scene stays live until the final pixel.</p></div></div>
              <div className="flex min-h-[250px] flex-col justify-between rounded-[26px] bg-[#242720] p-7 text-white"><div className="grid h-11 w-11 place-items-center rounded-2xl bg-[#3a3f34] text-[#e4e9dd]"><Download size={20} /></div><div><h3 className="text-[24px] font-bold tracking-[-.04em]">Pixels or paths.</h3><p className="mt-3 text-[13px] leading-6 text-[#abb1a5]">Export crisp PNGs up to 3×, or self-contained SVGs that stay editable.</p></div></div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1380px] px-5 py-20 sm:px-8 lg:py-28">
        <div className="mb-10 flex items-end justify-between gap-6"><div><p className="mb-3 text-[10px] font-bold uppercase tracking-[0.2em] text-[#7b8373]">A head start</p><h2 className="text-[clamp(34px,4vw,52px)] font-semibold tracking-[-0.055em]">Scenes with good instincts.</h2></div><Link to="/gallery" className="group hidden items-center gap-2 text-[13px] font-bold sm:inline-flex">Browse all scenes <MoveUpRight size={16} className="transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" /></Link></div>
        {templateError ? <div className="rounded-2xl border border-red-200 bg-red-50 p-5 text-sm text-red-700">{templateError} <Link to="/gallery" className="ml-2 font-bold underline">Open the full gallery</Link></div> : loading ? <div className="grid gap-5 md:grid-cols-3">{[1,2,3].map((i) => <div key={i} className="aspect-[4/4.2] animate-pulse rounded-[22px] bg-[#e7e8e1]" />)}</div> : <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{templates.map((template, index) => <TemplateCard key={template.id} template={template} onUse={useTemplate} index={index} />)}</div>}
        <Link to="/gallery" className="mt-8 inline-flex items-center gap-2 text-[13px] font-bold sm:hidden">Browse all scenes <ArrowRight size={16} /></Link>
      </section>

      <section id="how-it-works" className="bg-[#20231e] px-5 py-20 text-white sm:px-8 lg:py-28">
        <div className="mx-auto max-w-[1280px]">
          <div className="grid gap-12 lg:grid-cols-[.7fr_1.3fr]"><div><p className="mb-4 text-[10px] font-bold uppercase tracking-[0.2em] text-[#a6b78a]">From flat to fantastic</p><h2 className="text-[clamp(38px,4vw,58px)] font-semibold leading-[1.02] tracking-[-0.055em]">Three steps.<br /><span className="font-serif font-normal italic text-[#d9ff68]">Zero fuss.</span></h2><p className="mt-6 max-w-[360px] text-[14px] leading-6 text-[#aeb4a8]">No 3D software, no complicated timelines. Just the controls that make a difference.</p></div>
            <div>{[
              ['01', 'Bring your screen', 'Upload a PNG, JPEG or WebP, paste an image URL, or start with one of our editable sample interfaces.'],
              ['02', 'Find your angle', 'Pick a device and scene. Tune the finish, crop, rotation, backdrop and light until it feels right.'],
              ['03', 'Send it out into the world', 'Save your project, share a live link, or download a high-resolution PNG or editable SVG. No watermark.'],
            ].map(([number, title, copy]) => <div key={number} className="grid grid-cols-[50px_1fr] gap-5 border-t border-[#41463b] py-8 last:border-b sm:grid-cols-[70px_1fr]"><span className="font-mono text-[12px] text-[#d9ff68]">{number}</span><div><h3 className="text-[21px] font-bold tracking-[-.03em]">{title}</h3><p className="mt-3 max-w-[560px] text-[13px] leading-6 text-[#aeb4a8]">{copy}</p></div></div>)}</div>
          </div>
        </div>
      </section>

      <section className="px-5 py-16 sm:px-8 lg:py-24"><div className="relative mx-auto max-w-[1380px] overflow-hidden rounded-[30px] bg-[#e0f3ae] px-6 py-16 text-center sm:px-12 lg:py-24"><div className="absolute -left-16 -top-20 h-64 w-64 rounded-full border-[45px] border-[#cce68f] opacity-60" /><div className="absolute -bottom-24 -right-10 h-72 w-72 rotate-12 rounded-[60px] border-[45px] border-[#cce68f] opacity-50" /><div className="relative"><p className="text-[10px] font-bold uppercase tracking-[.2em] text-[#667545]">Your next launch called</p><h2 className="mx-auto mt-5 max-w-[800px] text-[clamp(40px,5vw,68px)] font-semibold leading-[.98] tracking-[-.06em]">Give good work a<br /><span className="font-serif font-normal italic text-[#637542]">great first impression.</span></h2><Link to="/studio" className="group mt-8 inline-flex items-center gap-3 rounded-full bg-[#20231e] px-7 py-4 text-[14px] font-semibold text-white transition-transform hover:-translate-y-1">Open the studio <ArrowUpRight size={18} className="transition-transform group-hover:rotate-45" /></Link></div></div></section>
    </main>
    <footer className="border-t border-[#dcdfd4] px-5 py-10 sm:px-8"><div className="mx-auto flex max-w-[1380px] flex-col justify-between gap-8 sm:flex-row sm:items-end"><div><Logo /><p className="mt-3 text-[12px] text-[#7c8276]">Real devices. Real control. Really good-looking work.</p></div><div className="flex flex-wrap gap-6 text-[12px] font-semibold text-[#656c60]"><Link to="/studio">Studio</Link><Link to="/gallery">Gallery</Link><Link to="/projects">My projects</Link><a href="/#how-it-works">How it works</a></div><p className="text-[10px] text-[#959a90]">© 2026 Mockly. Make something worth framing.</p></div></footer>
  </div>;
}
