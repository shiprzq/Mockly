import { useCallback, useEffect, useRef, useState } from 'react';
import type { ChangeEvent, CSSProperties, DragEvent, PointerEvent as ReactPointerEvent, ReactNode } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  AlignCenter, AlignLeft, ArrowDownToLine, Check, Cloud, Code2, Crop, Download, Eye,
  FileImage, FolderOpen, Image as ImageIcon, Laptop, Link2, LoaderCircle, Maximize2, Minus,
  MousePointer2, Move, Palette, PanelsTopLeft, Plus, Redo2, RotateCcw, Save, Share2,
  Smartphone, Sparkles, Tablet, Type, Undo2, Upload, Watch, X, Zap,
} from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import Logo from '../components/Logo';
import MockupCanvas from '../components/MockupCanvas';
import SampleArtwork from '../components/SampleArtwork';
import {
  apiRequest, fileToBase64, getOwnerKey, readDraft, saveDraft, type Asset, type Project,
} from '../lib/api';
import {
  backgroundPresets, canvasPresets, deviceLabels, getCanvasPreset, normalizeConfig,
  sampleDefinitions, type DeviceType, type MockupConfig, type SampleName,
} from '../lib/config';
import { exportMockup } from '../lib/export';

const deviceOptions: Array<{ id: DeviceType; icon: typeof Smartphone; note: string }> = [
  { id: 'phone', icon: Smartphone, note: 'iPhone-style' },
  { id: 'tablet', icon: Tablet, note: 'Edge-to-edge' },
  { id: 'laptop', icon: Laptop, note: 'Aluminum notebook' },
  { id: 'browser', icon: PanelsTopLeft, note: 'Clean desktop' },
  { id: 'watch', icon: Watch, note: 'Wearable' },
];

const finishes: Array<{ id: MockupConfig['finish']; label: string; color: string }> = [
  { id: 'graphite', label: 'Graphite', color: '#343832' },
  { id: 'silver', label: 'Silver', color: '#d7dad5' },
  { id: 'gold', label: 'Soft gold', color: '#d6c09e' },
  { id: 'blue', label: 'Pacific blue', color: '#88a5b8' },
  { id: 'coral', label: 'Coral', color: '#cb7460' },
];

function Slider({ label, value, min, max, step = 1, unit = '', onChange }: { label: string; value: number; min: number; max: number; step?: number; unit?: string; onChange: (value: number) => void }) {
  return <label className="block py-2.5"><span className="mb-2.5 flex items-center justify-between text-[11px] font-semibold text-[#656c5f]"><span>{label}</span><span className="rounded-md bg-[#eceee6] px-2 py-0.5 font-mono text-[10px] text-[#747b6e]">{Math.round(value * 100) / 100}{unit}</span></span><input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} className="w-full" /></label>;
}

function Toggle({ label, description, checked, onChange }: { label: string; description?: string; checked: boolean; onChange: (checked: boolean) => void }) {
  return <button type="button" role="switch" aria-checked={checked} onClick={() => onChange(!checked)} className="flex w-full items-center justify-between gap-4 py-3 text-left"><span><span className="block text-[12px] font-semibold text-[#42483e]">{label}</span>{description && <span className="mt-0.5 block text-[10px] leading-4 text-[#92978d]">{description}</span>}</span><span className={`relative h-[22px] w-[38px] shrink-0 rounded-full transition-colors ${checked ? 'bg-[#2a3024]' : 'bg-[#d4d8cd]'}`}><span className={`absolute top-[3px] h-4 w-4 rounded-full bg-white shadow-sm transition-transform ${checked ? 'translate-x-[18px]' : 'translate-x-[3px]'}`} /></span></button>;
}

function ColorField({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return <label className="flex items-center justify-between py-2 text-[11px] font-semibold text-[#656c5f]"><span>{label}</span><span className="flex h-8 items-center gap-2 rounded-lg border border-[#dcdfd5] bg-white px-2"><span className="font-mono text-[9px] uppercase text-[#82887d]">{value}</span><input type="color" value={value} onChange={(e) => onChange(e.target.value)} className="h-5 w-6 rounded border-0 bg-transparent p-0" aria-label={`${label} color`} /></span></label>;
}

function SectionTitle({ icon: Icon, children, action }: { icon?: typeof Palette; children: ReactNode; action?: ReactNode }) {
  return <div className="mb-2 mt-5 flex items-center justify-between border-t border-[#e3e5dc] pt-5 first:mt-0 first:border-0 first:pt-0"><h3 className="inline-flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.14em] text-[#737a6d]">{Icon && <Icon size={13} />}{children}</h3>{action}</div>;
}

function Segmented<T extends string>({ value, options, onChange }: { value: T; options: Array<{ value: T; label: string }>; onChange: (value: T) => void }) {
  return <div className="grid auto-cols-fr grid-flow-col rounded-xl bg-[#e9ece3] p-1">{options.map((option) => <button type="button" key={option.value} onClick={() => onChange(option.value)} className={`rounded-[9px] px-2 py-2 text-[10px] font-bold transition ${value === option.value ? 'bg-white text-[#282d24] shadow-sm' : 'text-[#7a8173] hover:text-[#343a2f]'}`}>{option.label}</button>)}</div>;
}

function StudioLoader() {
  return <div className="grid min-h-screen place-items-center bg-[#f2f3ed]"><div className="text-center"><Logo /><div className="mt-6 flex items-center gap-2 text-xs font-semibold text-[#7d8476]"><LoaderCircle size={16} className="animate-spin" /> Opening your scene…</div></div></div>;
}

export default function StudioPage() {
  const [searchParams] = useSearchParams();
  const requestedProject = searchParams.get('project');
  const isFreshScene = searchParams.get('new') === '1';
  const [initialDraft] = useState(() => isFreshScene ? null : readDraft());
  const [config, setConfig] = useState<MockupConfig>(() => normalizeConfig(initialDraft?.config));
  const [projectName, setProjectName] = useState(initialDraft?.name || 'Untitled scene');
  const [projectId, setProjectId] = useState<string | null>(initialDraft?.projectId || null);
  const [loadingProject, setLoadingProject] = useState(Boolean(requestedProject));
  const [ownerKey] = useState(getOwnerKey);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [assetsLoading, setAssetsLoading] = useState(true);
  const [sourceTab, setSourceTab] = useState<'samples' | 'upload' | 'url'>(initialDraft?.config?.screen?.mode === 'image' ? 'upload' : 'samples');
  const [mobilePanel, setMobilePanel] = useState<'device' | 'design'>('device');
  const [inspectorTab, setInspectorTab] = useState<'scene' | 'screen' | 'caption'>('scene');
  const [zoom, setZoom] = useState(82);
  const [urlInput, setUrlInput] = useState('');
  const [urlLoading, setUrlLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [exportFormat, setExportFormat] = useState<'png' | 'svg'>('png');
  const [exportScale, setExportScale] = useState(2);
  const [exporting, setExporting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [past, setPast] = useState<MockupConfig[]>([]);
  const [future, setFuture] = useState<MockupConfig[]>([]);
  const svgRef = useRef<SVGSVGElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const drag = useRef<{ pointerId: number; startX: number; startY: number; x: number; y: number; scaleX: number; scaleY: number } | null>(null);

  const notify = useCallback((text: string, type: 'success' | 'error' = 'success') => setToast({ text, type }), []);
  useEffect(() => { if (!toast) return; const timer = setTimeout(() => setToast(null), 4200); return () => clearTimeout(timer); }, [toast]);

  const fetchAssets = useCallback(async () => {
    try { setAssets(await apiRequest<Asset[]>(`/api/assets?ownerKey=${encodeURIComponent(ownerKey)}`)); }
    catch (err) { notify(err instanceof Error ? err.message : 'Could not load your uploads.', 'error'); }
    finally { setAssetsLoading(false); }
  }, [ownerKey, notify]);
  useEffect(() => {
    const timer = window.setTimeout(() => { void fetchAssets(); }, 0);
    return () => window.clearTimeout(timer);
  }, [fetchAssets]);

  useEffect(() => {
    if (!requestedProject) return;
    apiRequest<Project>(`/api/projects?id=${requestedProject}&ownerKey=${encodeURIComponent(ownerKey)}`)
      .then((project) => {
        setConfig(normalizeConfig(project.config)); setProjectName(project.name); setProjectId(project.id);
        setSourceTab(project.config.screen.mode === 'image' ? 'upload' : 'samples');
      })
      .catch((err) => notify(err.message, 'error'))
      .finally(() => setLoadingProject(false));
  }, [requestedProject, ownerKey, notify]);

  useEffect(() => { saveDraft(config, projectName, projectId); }, [config, projectName, projectId]);

  const commit = useCallback((recipe: (previous: MockupConfig) => MockupConfig) => {
    const next = recipe(config);
    if (JSON.stringify(next) === JSON.stringify(config)) return;
    setPast((items) => [...items.slice(-39), config]);
    setFuture([]);
    setConfig(next);
  }, [config]);

  const patch = <K extends keyof MockupConfig>(key: K, value: MockupConfig[K]) => commit((previous) => ({ ...previous, [key]: value }));
  const patchScreen = (value: Partial<MockupConfig['screen']>) => commit((previous) => ({ ...previous, screen: { ...previous.screen, ...value } }));
  const patchBackground = (value: Partial<MockupConfig['background']>) => commit((previous) => ({ ...previous, background: { ...previous.background, ...value } }));
  const patchCaption = (value: Partial<MockupConfig['caption']>) => commit((previous) => ({ ...previous, caption: { ...previous.caption, ...value } }));

  const undo = useCallback(() => {
    const previous = past[past.length - 1];
    if (!previous) return;
    setPast((items) => items.slice(0, -1));
    setFuture((items) => [...items, config]);
    setConfig(previous);
  }, [config, past]);
  const redo = useCallback(() => {
    const next = future[future.length - 1];
    if (!next) return;
    setFuture((items) => items.slice(0, -1));
    setPast((items) => [...items, config]);
    setConfig(next);
  }, [config, future]);

  const saveProject = useCallback(async (): Promise<Project | null> => {
    if (!projectName.trim()) { notify('Give your project a name before saving.', 'error'); return null; }
    setSaving(true);
    try {
      const payload = { ownerKey, name: projectName.trim(), config, device: config.device, screenshotUrl: config.screen.mode === 'image' ? config.screen.url : null };
      const project = await apiRequest<Project>('/api/projects', {
        method: projectId ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(projectId ? { ...payload, id: projectId } : payload),
      });
      setProjectId(project.id);
      notify(projectId ? 'Project saved.' : 'Project added to your shelf.');
      return project;
    } catch (err) { notify(err instanceof Error ? err.message : 'Could not save the project.', 'error'); return null; }
    finally { setSaving(false); }
  }, [config, projectId, projectName, ownerKey, notify]);

  const shareProject = async () => {
    const saved = await saveProject();
    if (!saved) return;
    try {
      const shared = saved.is_shared ? saved : await apiRequest<Project>('/api/projects', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ownerKey, id: saved.id, isShared: true }) });
      const url = `${window.location.origin}/share/${shared.id}`;
      try { await navigator.clipboard.writeText(url); notify('Public link copied. Anyone with it can view and remix.'); }
      catch { window.prompt('Copy your public scene link:', url); }
    } catch (err) { notify(err instanceof Error ? err.message : 'Could not share this scene.', 'error'); }
  };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement;
      const typing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName) || target.isContentEditable;
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 's') { event.preventDefault(); saveProject(); return; }
      if (typing) return;
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'z') { event.preventDefault(); if (event.shiftKey) redo(); else undo(); return; }
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'y') { event.preventDefault(); redo(); return; }
      if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) {
        event.preventDefault();
        const amount = event.shiftKey ? 20 : 4;
        commit((previous) => ({ ...previous, x: previous.x + (event.key === 'ArrowLeft' ? -amount : event.key === 'ArrowRight' ? amount : 0), y: previous.y + (event.key === 'ArrowUp' ? -amount : event.key === 'ArrowDown' ? amount : 0) }));
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [commit, redo, saveProject, undo]);

  const selectDevice = (device: DeviceType) => {
    commit((previous) => {
      const needsDesktop = device === 'laptop' || device === 'browser';
      const definition = sampleDefinitions.find((item) => item.id === previous.screen.sample);
      const layout = needsDesktop ? 'desktop' : 'mobile';
      const replacement = previous.screen.mode === 'sample' && definition?.layout !== layout ? sampleDefinitions.find((item) => item.layout === layout)! : definition!;
      const scales: Record<DeviceType, number> = { phone: .88, tablet: .72, laptop: .72, browser: .76, watch: 1.18 };
      return { ...previous, device, scale: scales[device], screen: previous.screen.mode === 'sample' ? { ...previous.screen, sample: replacement.id, title: replacement.title, accent: replacement.accent } : previous.screen };
    });
  };

  const selectSample = (sample: SampleName) => {
    const definition = sampleDefinitions.find((item) => item.id === sample)!;
    patchScreen({ mode: 'sample', sample, title: definition.title, accent: definition.accent });
  };

  const readDimensions = (url: string) => new Promise<{ width: number; height: number }>((resolve, reject) => {
    const image = new window.Image();
    const timeout = window.setTimeout(() => reject(new Error('The image took too long to respond.')), 10000);
    image.onload = () => { clearTimeout(timeout); resolve({ width: image.naturalWidth, height: image.naturalHeight }); };
    image.onerror = () => { clearTimeout(timeout); reject(new Error('That image could not be loaded. Check the URL and try again.')); };
    image.src = url;
  });

  const uploadFile = async (file?: File) => {
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) { notify('Choose a PNG, JPEG or WebP image.', 'error'); return; }
    if (file.size > 3 * 1024 * 1024) { notify('That file is over 3 MB. Compress it and try again.', 'error'); return; }
    setUploading(true);
    try {
      const localUrl = URL.createObjectURL(file);
      const dimensions = await readDimensions(localUrl);
      URL.revokeObjectURL(localUrl);
      const fileBase64 = await fileToBase64(file);
      const asset = await apiRequest<Asset>('/api/upload', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ownerKey, fileName: file.name, fileBase64, contentType: file.type, ...dimensions }) });
      setAssets((items) => [asset, ...items]);
      patchScreen({ mode: 'image', url: asset.url, zoom: 1, panX: 0, panY: 0 });
      notify('Screenshot uploaded and placed.');
    } catch (err) { notify(err instanceof Error ? err.message : 'Upload failed.', 'error'); }
    finally { setUploading(false); if (fileRef.current) fileRef.current.value = ''; }
  };

  const addUrl = async () => {
    let url: URL;
    try { url = new URL(urlInput); if (!['http:', 'https:'].includes(url.protocol)) throw new Error(); }
    catch { notify('Enter a complete image URL starting with http:// or https://.', 'error'); return; }
    setUrlLoading(true);
    try { await readDimensions(url.href); patchScreen({ mode: 'image', url: url.href, zoom: 1, panX: 0, panY: 0 }); notify('Image URL placed on the device.'); }
    catch (err) { notify(err instanceof Error ? err.message : 'Could not load that image.', 'error'); }
    finally { setUrlLoading(false); }
  };

  const deleteAsset = async (asset: Asset) => {
    try {
      await apiRequest('/api/assets', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ownerKey, id: asset.id }) });
      setAssets((items) => items.filter((item) => item.id !== asset.id));
      if (config.screen.url === asset.url) patchScreen({ url: '' });
      notify('Upload removed.');
    } catch (err) { notify(err instanceof Error ? err.message : 'Could not remove upload.', 'error'); }
  };

  const onDeviceDown = (event: ReactPointerEvent<SVGGElement>) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    setPast((items) => [...items.slice(-39), config]);
    setFuture([]);
    drag.current = { pointerId: event.pointerId, startX: event.clientX, startY: event.clientY, x: config.x, y: config.y, scaleX: config.canvasWidth / rect.width, scaleY: config.canvasHeight / rect.height };
    event.currentTarget.setPointerCapture(event.pointerId);
  };
  const onPointerMove = (event: ReactPointerEvent<SVGSVGElement>) => {
    if (!drag.current || drag.current.pointerId !== event.pointerId) return;
    const state = drag.current;
    setConfig((previous) => ({ ...previous, x: Math.round(state.x + (event.clientX - state.startX) * state.scaleX), y: Math.round(state.y + (event.clientY - state.startY) * state.scaleY) }));
  };
  const onPointerUp = (event: ReactPointerEvent<SVGSVGElement>) => {
    if (drag.current?.pointerId === event.pointerId) drag.current = null;
  };

  const doExport = async () => {
    if (!svgRef.current) return;
    setExporting(true);
    try { await exportMockup(svgRef.current, config, exportFormat, exportScale, projectName); setExportOpen(false); notify(`${exportFormat.toUpperCase()} downloaded. Looking good.`); }
    catch (err) { notify(err instanceof Error ? err.message : 'Export failed.', 'error'); }
    finally { setExporting(false); }
  };

  const handleDrop = (event: DragEvent) => { event.preventDefault(); setDragActive(false); uploadFile(event.dataTransfer.files[0]); };
  const activePreset = getCanvasPreset(config);

  const devicePanel = <>
    <div className="border-b border-[#e1e4da] px-5 py-4"><p className="text-[10px] font-bold uppercase tracking-[.16em] text-[#848b7c]">01 / Frame it</p><h2 className="mt-1 text-[17px] font-bold tracking-[-.03em]">Device & artwork</h2></div>
    <div className="p-4">
      <div className="grid grid-cols-5 gap-1 rounded-2xl bg-[#eceee7] p-1">{deviceOptions.map(({ id, icon: Icon }) => <button key={id} onClick={() => selectDevice(id)} title={deviceLabels[id]} className={`flex flex-col items-center gap-1.5 rounded-xl px-1 py-2.5 transition ${config.device === id ? 'bg-white text-[#252b20] shadow-sm' : 'text-[#858c7e] hover:text-[#41483b]'}`}><Icon size={19} strokeWidth={1.7} /><span className="text-[8px] font-bold">{deviceLabels[id]}</span></button>)}</div>
      <p className="mt-2 text-center text-[9px] text-[#969c90]">{deviceOptions.find((item) => item.id === config.device)?.note}</p>
      <div className="mt-5"><Segmented value={sourceTab} onChange={setSourceTab} options={[{ value: 'samples', label: 'Samples' }, { value: 'upload', label: 'Upload' }, { value: 'url', label: 'URL' }]} /></div>

      {sourceTab === 'samples' && <div className="mt-4 grid grid-cols-2 gap-2">{sampleDefinitions.map((sample) => <button key={sample.id} onClick={() => selectSample(sample.id)} className={`group overflow-hidden rounded-xl border text-left transition ${config.screen.mode === 'sample' && config.screen.sample === sample.id ? 'border-[#718748] ring-2 ring-[#dce9c4]' : 'border-[#dfe2d8] hover:border-[#b7beac]'}`}><div className="relative h-[92px] overflow-hidden bg-[#eceee7]"><SampleArtwork sample={sample.id} title={sample.title} accent={sample.accent} />{config.screen.mode === 'sample' && config.screen.sample === sample.id && <span className="absolute right-1.5 top-1.5 grid h-5 w-5 place-items-center rounded-full bg-[#d9ff68] text-[#293020]"><Check size={11} strokeWidth={3} /></span>}</div><div className="bg-white p-2.5"><p className="text-[11px] font-bold">{sample.name}</p><p className="mt-0.5 truncate text-[8px] text-[#8b9185]">{sample.layout === 'mobile' ? 'App interface' : 'Web interface'}</p></div></button>)}</div>}

      {sourceTab === 'upload' && <div className="mt-4">
        <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e: ChangeEvent<HTMLInputElement>) => uploadFile(e.target.files?.[0])} />
        <button onClick={() => fileRef.current?.click()} onDragOver={(e) => { e.preventDefault(); setDragActive(true); }} onDragLeave={() => setDragActive(false)} onDrop={handleDrop} disabled={uploading} className={`flex min-h-[148px] w-full flex-col items-center justify-center rounded-2xl border border-dashed px-4 text-center transition ${dragActive ? 'border-[#7c9650] bg-[#eef6df]' : 'border-[#cbd0c2] bg-[#f1f3ec] hover:bg-[#edf2e4]'}`}>{uploading ? <LoaderCircle className="animate-spin text-[#7e9259]" size={25} /> : <span className="grid h-10 w-10 place-items-center rounded-xl bg-white text-[#677356] shadow-sm"><Upload size={18} /></span>}<span className="mt-3 text-[12px] font-bold">{uploading ? 'Uploading your screen…' : 'Drop a screenshot here'}</span><span className="mt-1 text-[9px] leading-4 text-[#8b9284]">or click to browse · PNG, JPG, WebP<br />up to 3 MB</span></button>
        <div className="mt-5 flex items-center justify-between"><p className="text-[10px] font-bold uppercase tracking-[.12em] text-[#858c7e]">Your uploads</p><span className="text-[9px] text-[#9aa093]">{assets.length}/30</span></div>
        {assetsLoading ? <div className="mt-3 grid grid-cols-3 gap-2">{[1,2,3].map((i) => <div key={i} className="aspect-square animate-pulse rounded-lg bg-[#e4e7de]" />)}</div> : assets.length ? <div className="mt-3 grid grid-cols-3 gap-2">{assets.map((asset) => <div key={asset.id} className="group relative aspect-square overflow-hidden rounded-lg border border-[#dfe2d7] bg-[#e8eae3]"><button onClick={() => patchScreen({ mode: 'image', url: asset.url, zoom: 1, panX: 0, panY: 0 })} className="h-full w-full" title={asset.name}><img src={asset.url} alt={asset.name} className="h-full w-full object-cover" /></button><button onClick={() => deleteAsset(asset)} className="absolute right-1 top-1 hidden h-5 w-5 place-items-center rounded-full bg-[#20241d]/80 text-white group-hover:grid" aria-label={`Delete ${asset.name}`}><X size={11} /></button>{config.screen.url === asset.url && <span className="pointer-events-none absolute inset-x-0 bottom-0 bg-[#d9ff68] py-0.5 text-center text-[7px] font-bold">IN USE</span>}</div>)}</div> : <p className="mt-3 rounded-xl bg-[#eff1ea] p-3 text-center text-[10px] leading-4 text-[#8c9385]">Your uploaded screenshots will stay here for quick reuse.</p>}
      </div>}

      {sourceTab === 'url' && <div className="mt-4 rounded-2xl border border-[#dfe2d7] bg-[#f0f2eb] p-4"><span className="grid h-9 w-9 place-items-center rounded-xl bg-white text-[#78846a]"><Link2 size={17} /></span><h3 className="mt-3 text-[12px] font-bold">Place a hosted image</h3><p className="mt-1 text-[10px] leading-4 text-[#858d7e]">Use a direct link to a PNG, JPEG or WebP. For reliable export, uploading is recommended.</p><label className="mt-4 block text-[9px] font-bold uppercase tracking-[.1em] text-[#7b8374]">Image URL</label><input value={urlInput} onChange={(e) => setUrlInput(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') addUrl(); }} placeholder="https://example.com/screen.png" className="mt-2 h-10 w-full rounded-lg border border-[#d6dbd0] bg-white px-3 text-[10px] outline-none focus:border-[#92a573]" /><button onClick={addUrl} disabled={urlLoading || !urlInput.trim()} className="mt-2 flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-[#272c23] text-[10px] font-bold text-white disabled:opacity-50">{urlLoading ? <LoaderCircle size={14} className="animate-spin" /> : <Link2 size={13} />} Place image</button></div>}
    </div>
  </>;

  const designPanel = <>
    <div className="border-b border-[#e1e4da] px-5 py-4"><p className="text-[10px] font-bold uppercase tracking-[.16em] text-[#848b7c]">02 / Make it yours</p><h2 className="mt-1 text-[17px] font-bold tracking-[-.03em]">Art direction</h2></div>
    <div className="border-b border-[#e1e4da] p-3"><Segmented value={inspectorTab} onChange={setInspectorTab} options={[{ value: 'scene', label: 'Scene' }, { value: 'screen', label: 'Screen' }, { value: 'caption', label: 'Caption' }]} /></div>
    <div className="p-4 pb-8">
      {inspectorTab === 'scene' && <>
        <SectionTitle icon={Maximize2}>Canvas size</SectionTitle>
        <div className="grid grid-cols-2 gap-2">
          <label className="text-[9px] font-bold uppercase tracking-[.1em] text-[#858d7d]">Width (px)<input type="number" min={320} max={3000} step={10} value={config.canvasWidth} onChange={(e) => patch('canvasWidth', Math.max(320, Math.min(3000, Number(e.target.value) || 320)))} className="mt-2 h-10 w-full rounded-lg border border-[#dcdfd5] bg-white px-3 font-mono text-[11px] normal-case tracking-normal outline-none focus:border-[#91a671]" /></label>
          <label className="text-[9px] font-bold uppercase tracking-[.1em] text-[#858d7d]">Height (px)<input type="number" min={320} max={3000} step={10} value={config.canvasHeight} onChange={(e) => patch('canvasHeight', Math.max(320, Math.min(3000, Number(e.target.value) || 320)))} className="mt-2 h-10 w-full rounded-lg border border-[#dcdfd5] bg-white px-3 font-mono text-[11px] normal-case tracking-normal outline-none focus:border-[#91a671]" /></label>
        </div>
        <p className="mt-2 text-[9px] leading-4 text-[#969d8f]">320–3000 px per side. Use the presets above the canvas for common ratios.</p>
        <SectionTitle icon={Palette}>Backdrop</SectionTitle>
        <div className="grid grid-cols-4 gap-2">{backgroundPresets.map((preset) => <button key={preset.name} title={preset.name} onClick={() => commit((previous) => ({ ...previous, background: { ...previous.background, type: 'gradient', from: preset.from, to: preset.to } }))} className={`relative h-11 rounded-xl border-2 transition hover:-translate-y-0.5 ${config.background.from === preset.from && config.background.to === preset.to ? 'border-[#414a37]' : 'border-white shadow-sm'}`} style={{ background: `linear-gradient(135deg, ${preset.from}, ${preset.to})` }}><span className="sr-only">{preset.name}</span></button>)}</div>
        <div className="mt-4"><Segmented value={config.background.type} onChange={(type) => patchBackground({ type })} options={[{ value: 'gradient', label: 'Gradient' }, { value: 'solid', label: 'Solid' }, { value: 'transparent', label: 'Clear' }]} /></div>
        {config.background.type !== 'transparent' ? <div className="mt-2"><ColorField label={config.background.type === 'gradient' ? 'Start color' : 'Color'} value={config.background.from} onChange={(from) => patchBackground({ from })} />{config.background.type === 'gradient' && <><ColorField label="End color" value={config.background.to} onChange={(to) => patchBackground({ to })} /><Slider label="Gradient angle" value={config.background.angle} min={0} max={360} unit="°" onChange={(angle) => patchBackground({ angle })} /></>}<label className="mt-2 block text-[11px] font-semibold text-[#656c5f]">Texture<select value={config.background.pattern} onChange={(e) => patchBackground({ pattern: e.target.value as MockupConfig['background']['pattern'] })} className="mt-2 h-10 w-full rounded-lg border border-[#dcdfd5] bg-white px-3 text-[11px] outline-none"><option value="none">None — clean finish</option><option value="dots">Subtle dot grid</option><option value="grid">Editorial grid</option></select></label></div> : <div className="studio-checker mt-4 flex h-20 items-center justify-center rounded-xl border border-[#d9ddd2] text-[10px] font-bold text-[#737c69]">Transparent canvas</div>}
        <SectionTitle icon={Sparkles}>Device finish</SectionTitle>
        <div className="flex items-center justify-between py-2">{finishes.map((finish) => <button key={finish.id} onClick={() => patch('finish', finish.id)} title={finish.label} className={`grid h-9 w-9 place-items-center rounded-full border-2 ${config.finish === finish.id ? 'border-[#4a5540]' : 'border-transparent'}`}><span className="h-6 w-6 rounded-full border border-black/10 shadow-inner" style={{ backgroundColor: finish.color }} /></button>)}</div>
        <SectionTitle icon={Move}>Composition</SectionTitle>
        <Slider label="Device scale" value={config.scale} min={.3} max={1.6} step={.01} unit="×" onChange={(scale) => patch('scale', scale)} />
        <Slider label="Rotation" value={config.rotation} min={-35} max={35} unit="°" onChange={(rotation) => patch('rotation', rotation)} />
        <Slider label="Horizontal" value={config.x} min={-600} max={600} unit=" px" onChange={(x) => patch('x', x)} />
        <Slider label="Vertical" value={config.y} min={-700} max={700} unit=" px" onChange={(y) => patch('y', y)} />
        <button onClick={() => commit((previous) => ({ ...previous, x: 0, y: 0, rotation: 0 }))} className="mt-2 inline-flex items-center gap-1.5 text-[10px] font-bold text-[#77846a] hover:text-[#39432f]"><RotateCcw size={12} /> Reset position & angle</button>
        <SectionTitle icon={Zap}>Light & texture</SectionTitle>
        <Slider label="Soft shadow" value={config.shadow} min={0} max={100} unit="%" onChange={(shadow) => patch('shadow', shadow)} />
        <Toggle label="Screen glare" description="A subtle studio-light reflection" checked={config.glare} onChange={(glare) => patch('glare', glare)} />
        <Toggle label="Fine film grain" description="Adds tactile texture to the backdrop" checked={config.grain} onChange={(grain) => patch('grain', grain)} />
      </>}

      {inspectorTab === 'screen' && <>
        <SectionTitle icon={Crop}>Screen settings</SectionTitle>
        {config.screen.mode === 'sample' ? <><label className="block py-2 text-[11px] font-semibold text-[#656c5f]">Interface name<input value={config.screen.title} maxLength={22} onChange={(e) => patchScreen({ title: e.target.value })} className="mt-2 h-10 w-full rounded-lg border border-[#dcdfd5] bg-white px-3 text-[12px] outline-none focus:border-[#91a671]" /></label><ColorField label="Accent color" value={config.screen.accent} onChange={(accent) => patchScreen({ accent })} /><div className="mt-4 rounded-xl bg-[#edf0e7] p-3 text-[10px] leading-5 text-[#7b8374]">This is a live vector interface, not a flat thumbnail. Change the name and accent, then switch samples from the device panel.</div><button onClick={() => setSourceTab('samples')} className="mt-4 flex h-10 w-full items-center justify-center gap-2 rounded-lg border border-[#d5dacf] bg-white text-[10px] font-bold"><ImageIcon size={14} /> Choose another sample</button></> : <>
          <div className="mb-4"><Segmented value={config.screen.fit} onChange={(fit) => patchScreen({ fit })} options={[{ value: 'cover', label: 'Fill screen' }, { value: 'contain', label: 'Fit inside' }]} /></div>
          <Slider label="Image zoom" value={config.screen.zoom} min={.5} max={3} step={.01} unit="×" onChange={(zoom) => patchScreen({ zoom })} />
          <Slider label="Horizontal crop" value={config.screen.panX} min={-500} max={500} unit=" px" onChange={(panX) => patchScreen({ panX })} />
          <Slider label="Vertical crop" value={config.screen.panY} min={-700} max={700} unit=" px" onChange={(panY) => patchScreen({ panY })} />
          <button onClick={() => patchScreen({ zoom: 1, panX: 0, panY: 0, fit: 'cover' })} className="mt-3 flex h-10 w-full items-center justify-center gap-2 rounded-lg border border-[#d5dacf] bg-white text-[10px] font-bold"><Crop size={13} /> Reset crop</button>
          {!config.screen.url && <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-[10px] leading-5 text-amber-800">No image is selected. Add an upload or image URL from the device panel.</div>}
        </>}
      </>}

      {inspectorTab === 'caption' && <>
        <SectionTitle icon={Type}>Presentation caption</SectionTitle>
        <Toggle label="Show caption" description="Adds a title and note to the canvas" checked={config.caption.show} onChange={(show) => patchCaption({ show })} />
        <div className={config.caption.show ? '' : 'pointer-events-none opacity-40'}><label className="mt-3 block text-[11px] font-semibold text-[#656c5f]">Title<input value={config.caption.title} onChange={(e) => patchCaption({ title: e.target.value })} maxLength={60} className="mt-2 h-10 w-full rounded-lg border border-[#dcdfd5] bg-white px-3 text-[11px] outline-none focus:border-[#91a671]" /><span className="mt-1 block text-right text-[8px] text-[#9aa093]">{config.caption.title.length}/60</span></label><label className="mt-2 block text-[11px] font-semibold text-[#656c5f]">Supporting line<textarea value={config.caption.subtitle} onChange={(e) => patchCaption({ subtitle: e.target.value })} maxLength={84} rows={3} className="mt-2 w-full resize-none rounded-lg border border-[#dcdfd5] bg-white p-3 text-[11px] leading-5 outline-none focus:border-[#91a671]" /></label><div className="mt-2 grid grid-cols-2 gap-2"><button onClick={() => patchCaption({ align: 'left' })} className={`flex h-10 items-center justify-center gap-2 rounded-lg border text-[10px] font-bold ${config.caption.align === 'left' ? 'border-[#859b63] bg-[#eef4e4]' : 'border-[#dcdfd5] bg-white'}`}><AlignLeft size={14} /> Left</button><button onClick={() => patchCaption({ align: 'center' })} className={`flex h-10 items-center justify-center gap-2 rounded-lg border text-[10px] font-bold ${config.caption.align === 'center' ? 'border-[#859b63] bg-[#eef4e4]' : 'border-[#dcdfd5] bg-white'}`}><AlignCenter size={14} /> Center</button></div><div className="mt-3"><ColorField label="Text color" value={config.caption.color} onChange={(color) => patchCaption({ color })} /></div></div>
      </>}
      <div className="mt-6 rounded-xl bg-[#e9ede1] p-3"><p className="flex items-center gap-2 text-[9px] font-bold uppercase tracking-[.1em] text-[#77826b]"><MousePointer2 size={12} /> Studio shortcuts</p><div className="mt-2 grid grid-cols-2 gap-2 text-[9px] text-[#858d7d]"><span>Arrows · Nudge</span><span>Shift + arrows · 20px</span><span>⌘/Ctrl Z · Undo</span><span>⌘/Ctrl S · Save</span></div></div>
    </div>
  </>;

  if (loadingProject) return <StudioLoader />;

  return <div data-history={past.length + future.length} className="min-h-screen bg-[#f4f5ef] text-[#252920] lg:h-screen lg:overflow-hidden">
    <header className="relative z-30 flex min-h-[64px] items-center justify-between gap-3 border-b border-[#dcdfd4] bg-[#fafaf7] px-3 sm:px-5">
      <div className="flex min-w-0 items-center gap-4"><Logo /><span className="hidden h-6 w-px bg-[#dcdfd4] sm:block" /><div className="hidden min-w-0 items-center gap-2 sm:flex"><input value={projectName} onChange={(e) => setProjectName(e.target.value)} onBlur={() => { if (!projectName.trim()) setProjectName('Untitled scene'); }} maxLength={80} className="w-[190px] truncate rounded-lg border border-transparent bg-transparent px-2 py-1.5 text-[12px] font-bold outline-none hover:border-[#dfe2d7] focus:border-[#b6c3a2] focus:bg-white lg:w-[240px]" aria-label="Project name" />{projectId && <span className="hidden items-center gap-1 text-[9px] text-[#939a8c] xl:inline-flex"><Cloud size={11} /> Saved project</span>}</div></div>
      <div className="flex shrink-0 items-center gap-1.5">
        <div className="mr-1 hidden items-center gap-1 md:flex"><button onClick={undo} disabled={!past.length} title="Undo" className="grid h-9 w-9 place-items-center rounded-lg text-[#737b6d] hover:bg-[#eceee6] disabled:opacity-30"><Undo2 size={16} /></button><button onClick={redo} disabled={!future.length} title="Redo" className="grid h-9 w-9 place-items-center rounded-lg text-[#737b6d] hover:bg-[#eceee6] disabled:opacity-30"><Redo2 size={16} /></button></div>
        <Link to="/projects" title="My projects" className="hidden h-9 w-9 place-items-center rounded-lg text-[#737b6d] hover:bg-[#eceee6] sm:grid"><FolderOpen size={16} /></Link>
        <button onClick={shareProject} className="hidden h-9 items-center gap-2 rounded-lg border border-[#d8dcd0] bg-white px-3 text-[10px] font-bold text-[#525b49] hover:bg-[#f0f2ea] sm:flex"><Share2 size={14} /> Share</button>
        <button onClick={() => saveProject()} disabled={saving} className="flex h-9 items-center gap-2 rounded-lg border border-[#d8dcd0] bg-white px-3 text-[10px] font-bold text-[#525b49] hover:bg-[#f0f2ea] disabled:opacity-60">{saving ? <LoaderCircle size={14} className="animate-spin" /> : <Save size={14} />}<span className="hidden xs:inline">{saving ? 'Saving' : 'Save'}</span></button>
        <button onClick={() => setExportOpen(true)} className="flex h-9 items-center gap-2 rounded-lg bg-[#252a21] px-3.5 text-[10px] font-bold text-white shadow-sm hover:bg-[#3b4334]"><Download size={14} /> Export</button>
      </div>
    </header>

    <div className="flex flex-col lg:h-[calc(100vh-64px)] lg:flex-row">
      <aside className={`thin-scroll order-2 w-full shrink-0 overflow-y-auto border-r border-[#dcdfd4] bg-[#f8f9f4] lg:order-1 lg:block lg:w-[268px] ${mobilePanel === 'device' ? 'block' : 'hidden'}`}>{devicePanel}</aside>

      <main className="order-1 flex min-w-0 flex-1 flex-col lg:order-2 lg:h-full">
        <div className="flex min-h-[52px] flex-wrap items-center justify-between gap-2 border-b border-[#d9ddd1] bg-[#f7f8f3] px-3 py-2 sm:px-4">
          <div className="flex items-center gap-1 overflow-x-auto">{canvasPresets.map((preset) => <button key={preset.id} onClick={() => commit((previous) => ({ ...previous, canvasWidth: preset.width, canvasHeight: preset.height }))} title={`${preset.label} ${preset.width}×${preset.height}`} className={`shrink-0 rounded-lg px-2.5 py-2 text-[9px] font-bold transition ${activePreset === preset.id ? 'bg-[#e2e9d7] text-[#46533a]' : 'text-[#899080] hover:bg-[#eceee7]'}`}>{preset.label}<span className="ml-1 hidden font-mono font-normal xl:inline">{preset.detail}</span></button>)}</div>
          <div className="flex items-center gap-1"><button onClick={() => setZoom((value) => Math.max(30, value - 10))} className="grid h-8 w-8 place-items-center rounded-lg text-[#7e8676] hover:bg-[#e8ebe2]" aria-label="Zoom out"><Minus size={14} /></button><button onClick={() => setZoom(82)} className="w-11 text-center font-mono text-[9px] font-semibold text-[#737b6c]">{zoom}%</button><button onClick={() => setZoom((value) => Math.min(180, value + 10))} className="grid h-8 w-8 place-items-center rounded-lg text-[#7e8676] hover:bg-[#e8ebe2]" aria-label="Zoom in"><Plus size={14} /></button></div>
        </div>
        <div className="dot-workspace thin-scroll relative flex min-h-[470px] flex-1 items-center justify-center overflow-auto p-5 sm:min-h-[560px] sm:p-8 lg:min-h-0">
          <div className="flex min-h-full min-w-full items-center justify-center">
            <div className="relative transition-[width] duration-200" style={{ width: `${zoom}%`, maxWidth: zoom <= 100 ? '980px' : 'none', minWidth: zoom > 100 ? `${Math.max(config.canvasWidth, config.canvasHeight) * zoom / 115}px` : '280px' } as CSSProperties}>
              <div className="overflow-hidden rounded-[3px] shadow-[0_18px_50px_rgba(37,45,29,.16)] ring-1 ring-black/10"><MockupCanvas ref={svgRef} config={config} interactive onDevicePointerDown={onDeviceDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp} onPointerCancel={onPointerUp} label={`${projectName} editing canvas`} /></div>
              <div className="pointer-events-none absolute -bottom-6 left-0 flex items-center gap-2 font-mono text-[8px] uppercase tracking-wider text-[#87907f]"><span>{config.canvasWidth} × {config.canvasHeight} px</span><span>·</span><span>{deviceLabels[config.device]}</span></div>
              <div className="pointer-events-none absolute -right-2 -top-2 h-4 w-4 rounded-full border-2 border-white bg-[#59664d] shadow-sm" data-export-hide="true" />
            </div>
          </div>
          <div className="pointer-events-none absolute bottom-4 left-4 hidden items-center gap-2 rounded-full bg-white/80 px-3 py-1.5 text-[9px] font-semibold text-[#7c8574] shadow-sm backdrop-blur sm:flex"><Move size={11} /> Drag device to compose</div>
        </div>
        <div className="grid grid-cols-2 gap-2 border-t border-[#d9ddd1] bg-[#f8f9f4] p-3 lg:hidden"><button onClick={() => setMobilePanel('device')} className={`flex items-center justify-center gap-2 rounded-xl py-3 text-[11px] font-bold ${mobilePanel === 'device' ? 'bg-[#252a21] text-white' : 'bg-[#e9ece3] text-[#66705d]'}`}><Smartphone size={15} /> Device & artwork</button><button onClick={() => setMobilePanel('design')} className={`flex items-center justify-center gap-2 rounded-xl py-3 text-[11px] font-bold ${mobilePanel === 'design' ? 'bg-[#252a21] text-white' : 'bg-[#e9ece3] text-[#66705d]'}`}><Palette size={15} /> Art direction</button></div>
      </main>

      <aside className={`thin-scroll order-3 w-full shrink-0 overflow-y-auto border-l border-[#dcdfd4] bg-[#f8f9f4] lg:block lg:w-[296px] ${mobilePanel === 'design' ? 'block' : 'hidden'}`}>{designPanel}</aside>
    </div>

    <AnimatePresence>{toast && <motion.div initial={{ opacity: 0, y: 16, x: '-50%' }} animate={{ opacity: 1, y: 0, x: '-50%' }} exit={{ opacity: 0, y: 10, x: '-50%' }} className={`fixed bottom-5 left-1/2 z-[70] flex max-w-[calc(100vw-32px)] items-center gap-3 rounded-full px-4 py-3 text-[11px] font-semibold text-white shadow-2xl ${toast.type === 'error' ? 'bg-[#853f35]' : 'bg-[#293023]'}`}><span className={`grid h-5 w-5 shrink-0 place-items-center rounded-full ${toast.type === 'error' ? 'bg-[#a95c4f]' : 'bg-[#d9ff68] text-[#293023]'}`}>{toast.type === 'error' ? <X size={12} /> : <Check size={12} />}</span><span>{toast.text}</span><button onClick={() => setToast(null)} className="ml-1 opacity-70"><X size={13} /></button></motion.div>}</AnimatePresence>

    <AnimatePresence>{exportOpen && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-[#171b13]/55 p-4 backdrop-blur-sm" onMouseDown={() => !exporting && setExportOpen(false)}><motion.div initial={{ opacity: 0, scale: .96, y: 16 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: .97, y: 8 }} onMouseDown={(e) => e.stopPropagation()} className="w-full max-w-[500px] rounded-[24px] bg-[#f9faf5] p-6 shadow-2xl sm:p-7">
      <div className="flex items-start justify-between"><div><p className="text-[9px] font-bold uppercase tracking-[.18em] text-[#89927e]">The final touch</p><h2 className="mt-1 text-[25px] font-bold tracking-[-.045em]">Export your scene</h2><p className="mt-1 text-[11px] text-[#858d7c]">High quality. No watermark. All yours.</p></div><button onClick={() => setExportOpen(false)} disabled={exporting} className="grid h-9 w-9 place-items-center rounded-full border border-[#dce0d5] text-[#737d69]"><X size={17} /></button></div>
      <div className="mt-6 grid grid-cols-2 gap-3"><button onClick={() => setExportFormat('png')} className={`rounded-2xl border p-4 text-left transition ${exportFormat === 'png' ? 'border-[#738951] bg-[#eef5e2] ring-2 ring-[#dce8c8]' : 'border-[#dce0d5] bg-white'}`}><FileImage size={21} className="text-[#63754a]" /><p className="mt-3 text-[13px] font-bold">PNG image</p><p className="mt-1 text-[9px] leading-4 text-[#87907e]">Crisp pixels for social, decks and launch posts.</p></button><button onClick={() => setExportFormat('svg')} className={`rounded-2xl border p-4 text-left transition ${exportFormat === 'svg' ? 'border-[#738951] bg-[#eef5e2] ring-2 ring-[#dce8c8]' : 'border-[#dce0d5] bg-white'}`}><Code2 size={21} className="text-[#63754a]" /><p className="mt-3 text-[13px] font-bold">Editable SVG</p><p className="mt-1 text-[9px] leading-4 text-[#87907e]">Infinitely scalable vector paths and embedded artwork.</p></button></div>
      <div className="mt-5"><div className="flex items-center justify-between"><label className="text-[11px] font-bold text-[#5f6856]">Export resolution</label><span className="font-mono text-[9px] text-[#8b9382]">{config.canvasWidth * (exportFormat === 'svg' ? 1 : exportScale)} × {config.canvasHeight * (exportFormat === 'svg' ? 1 : exportScale)} px</span></div><div className="mt-2 grid grid-cols-3 gap-2">{[1,2,3].map((scale) => <button key={scale} disabled={exportFormat === 'svg'} onClick={() => setExportScale(scale)} className={`rounded-xl border py-3 text-[11px] font-bold disabled:opacity-35 ${exportScale === scale && exportFormat === 'png' ? 'border-[#7f9362] bg-[#edf3e3] text-[#455438]' : 'border-[#dce0d5] bg-white text-[#7c8573]'}`}>{scale}×<span className="ml-1 text-[8px] font-normal">{scale === 1 ? 'Standard' : scale === 2 ? 'Recommended' : 'Maximum'}</span></button>)}</div></div>
      <div className="mt-4 border-t border-[#e1e4da]"><Toggle label="Transparent background" description="Removes backdrop color, pattern and grain" checked={config.background.type === 'transparent'} onChange={(checked) => patchBackground({ type: checked ? 'transparent' : 'gradient' })} /></div>
      <div className="mt-3 flex items-center gap-2 rounded-xl bg-[#eef0e9] p-3 text-[9px] leading-4 text-[#7d8673]"><Eye size={14} className="shrink-0" /> Uploaded and hosted images are embedded so your downloaded file travels intact.</div>
      <button onClick={doExport} disabled={exporting} className="mt-5 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#252a21] text-[12px] font-bold text-white transition hover:bg-[#3b4533] disabled:opacity-60">{exporting ? <LoaderCircle size={17} className="animate-spin" /> : <ArrowDownToLine size={17} />}{exporting ? 'Preparing your file…' : `Download ${exportFormat.toUpperCase()}`}</button>
      <p className="mt-3 text-center text-[9px] text-[#969d8e]">Your scene remains editable after export.</p>
    </motion.div></motion.div>}</AnimatePresence>
  </div>;
}
