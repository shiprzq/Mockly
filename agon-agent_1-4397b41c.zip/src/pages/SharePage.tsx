import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowUpRight, Download, LoaderCircle } from 'lucide-react';
import Logo from '../components/Logo';
import MockupCanvas from '../components/MockupCanvas';
import { apiRequest, stageTemplate, type Project } from '../lib/api';
import { deviceLabels, normalizeConfig, type MockupConfig } from '../lib/config';
import { exportMockup } from '../lib/export';

export default function SharePage() {
  const { id } = useParams();
  const [project, setProject] = useState<Project | null>(null);
  const [config, setConfig] = useState<MockupConfig | null>(null);
  const [error, setError] = useState('');
  const [exporting, setExporting] = useState(false);
  const svgRef = useRef<SVGSVGElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    apiRequest<Project>(`/api/projects?id=${id}`).then((data) => { setProject(data); setConfig(normalizeConfig(data.config)); }).catch((err) => setError(err.message));
  }, [id]);

  const download = async () => {
    if (!svgRef.current || !config || !project) return;
    setExporting(true); setError('');
    try { await exportMockup(svgRef.current, config, 'png', 2, project.name); }
    catch (err) { setError(err instanceof Error ? err.message : 'Export failed.'); }
    finally { setExporting(false); }
  };
  const remix = () => { if (!config || !project) return; stageTemplate(config, `${project.name} remix`); navigate('/studio'); };

  return <div className="min-h-screen bg-[#eff0e9] text-[#20231e]"><header className="border-b border-[#d9dcd1] bg-[#f8f8f3]"><div className="mx-auto flex h-[70px] max-w-[1400px] items-center justify-between px-5 sm:px-8"><Logo /><Link to="/studio" className="inline-flex items-center gap-2 text-[12px] font-bold">Open Mockly <ArrowUpRight size={15} /></Link></div></header>
    <main className="mx-auto max-w-[1280px] px-5 py-10 sm:px-8 lg:py-16">
      <Link to="/gallery" className="mb-7 inline-flex items-center gap-2 text-[11px] font-bold text-[#747c6e]"><ArrowLeft size={14} /> Explore more scenes</Link>
      {!project && !error && <div className="flex min-h-[60vh] items-center justify-center gap-3 text-sm text-[#767e70]"><LoaderCircle className="animate-spin" size={20} /> Preparing shared scene…</div>}
      {error && !project && <div className="mx-auto mt-24 max-w-md rounded-2xl border border-red-200 bg-red-50 p-8 text-center"><h1 className="text-xl font-bold text-red-800">Scene unavailable</h1><p className="mt-3 text-sm leading-6 text-red-700">{error}</p><Link to="/studio" className="mt-5 inline-block rounded-full bg-[#22261f] px-5 py-3 text-xs font-bold text-white">Create your own</Link></div>}
      {project && config && <><div className="mb-7 flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="mb-3 text-[10px] font-bold uppercase tracking-[.18em] text-[#7f8777]">Shared from Mockly · {deviceLabels[config.device]}</p><h1 className="text-[clamp(32px,4vw,52px)] font-semibold tracking-[-.055em]">{project.name}</h1></div><div className="flex gap-2"><button onClick={download} disabled={exporting} className="inline-flex items-center gap-2 rounded-full border border-[#cfd3c6] bg-white px-5 py-3 text-xs font-bold disabled:opacity-50">{exporting ? <LoaderCircle size={15} className="animate-spin" /> : <Download size={15} />} {exporting ? 'Exporting…' : 'Download PNG'}</button><button onClick={remix} className="inline-flex items-center gap-2 rounded-full bg-[#22261f] px-5 py-3 text-xs font-bold text-white">Remix scene <ArrowUpRight size={15} /></button></div></div>
      <div className="overflow-hidden rounded-[26px] border border-[#d5d8ce] bg-white p-3 shadow-[0_25px_60px_rgba(32,39,25,.1)] sm:p-5"><MockupCanvas ref={svgRef} config={config} className="mx-auto max-h-[75vh] w-auto max-w-full rounded-[16px]" label={project.name} /></div>
      {error && <p className="mt-4 rounded-xl bg-red-50 p-3 text-center text-xs text-red-700">{error}</p>}
      <p className="mt-5 text-center text-[11px] text-[#858c7f]">Made with Mockly — realistic device mockups, right in your browser.</p></>}
    </main>
  </div>;
}
