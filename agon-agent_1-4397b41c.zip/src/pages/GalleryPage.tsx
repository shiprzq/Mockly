import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, SlidersHorizontal } from 'lucide-react';
import Header from '../components/Header';
import TemplateCard from '../components/TemplateCard';
import { apiRequest, stageTemplate, type Template } from '../lib/api';

export default function GalleryPage() {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [category, setCategory] = useState('All');
  const [query, setQuery] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    apiRequest<Template[]>('/api/templates').then(setTemplates).catch((err) => setError(err.message)).finally(() => setLoading(false));
  }, []);

  const categories = useMemo(() => ['All', ...Array.from(new Set(templates.map((template) => template.category)))], [templates]);
  const filtered = templates.filter((template) => (category === 'All' || template.category === category) && `${template.name} ${template.description} ${template.device}`.toLowerCase().includes(query.toLowerCase()));
  const useTemplate = (template: Template) => { stageTemplate(template.config, template.name); navigate('/studio'); };

  return <div className="min-h-screen bg-[#f7f7f2] text-[#20231e]"><Header /><main className="mx-auto max-w-[1380px] px-5 py-12 sm:px-8 lg:py-16">
    <div className="flex flex-col justify-between gap-8 lg:flex-row lg:items-end"><div><p className="mb-4 text-[10px] font-bold uppercase tracking-[.2em] text-[#7d8476]">The starting point collection</p><h1 className="text-[clamp(42px,5vw,68px)] font-semibold leading-none tracking-[-.06em]">Find your <span className="font-serif font-normal italic text-[#71834d]">frame of mind.</span></h1><p className="mt-5 max-w-[560px] text-[15px] leading-6 text-[#71786c]">Individually art-directed scenes, ready for your screenshot. Every color, crop and angle is yours to change.</p></div><div className="relative w-full max-w-[340px]"><Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[#8b9185]" size={17} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search scenes…" className="h-12 w-full rounded-full border border-[#d8dbd0] bg-white pl-11 pr-4 text-[13px] outline-none transition focus:border-[#9dae78] focus:ring-4 focus:ring-[#dce8c4]/60" /></div></div>
    <div className="mb-9 mt-10 flex items-center gap-2 overflow-x-auto pb-2"><span className="mr-2 inline-flex shrink-0 items-center gap-2 text-[11px] font-bold text-[#858c7e]"><SlidersHorizontal size={14} /> FILTER</span>{categories.map((item) => <button key={item} onClick={() => setCategory(item)} className={`shrink-0 rounded-full px-4 py-2 text-[12px] font-semibold transition ${category === item ? 'bg-[#22261f] text-white' : 'border border-[#d9dcd2] bg-white text-[#636a5e] hover:border-[#adb5a2]'}`}>{item}</button>)}</div>
    {loading ? <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{[1,2,3,4,5,6].map((i) => <div key={i} className="aspect-[4/4.2] animate-pulse rounded-[22px] bg-[#e7e8e1]" />)}</div> : error ? <div className="rounded-2xl border border-red-200 bg-red-50 p-6 text-sm text-red-700">{error}<button onClick={() => window.location.reload()} className="ml-3 font-bold underline">Try again</button></div> : filtered.length ? <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{filtered.map((template, index) => <TemplateCard key={template.id} template={template} onUse={useTemplate} index={index} />)}</div> : <div className="rounded-[24px] border border-dashed border-[#cfd3c6] py-24 text-center"><p className="text-xl font-bold">No scenes found</p><p className="mt-2 text-sm text-[#7c8375]">Try another search or clear your filters.</p><button onClick={() => { setQuery(''); setCategory('All'); }} className="mt-5 rounded-full bg-[#22261f] px-5 py-2.5 text-xs font-bold text-white">Clear filters</button></div>}
  </main></div>;
}
