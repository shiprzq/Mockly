import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Copy, ExternalLink, FolderOpen, MoreHorizontal, Pencil, Plus, Share2, Trash2, X } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import Header from '../components/Header';
import MockupCanvas from '../components/MockupCanvas';
import { apiRequest, getOwnerKey, stageTemplate, type Project } from '../lib/api';
import { normalizeConfig } from '../lib/config';

export default function ProjectsPage() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [menu, setMenu] = useState<string | null>(null);
  const [renaming, setRenaming] = useState<Project | null>(null);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const navigate = useNavigate();
  const ownerKey = getOwnerKey();

  const fetchProjects = useCallback(async () => {
    setError('');
    try { setProjects(await apiRequest<Project[]>(`/api/projects?ownerKey=${encodeURIComponent(ownerKey)}`)); }
    catch (err) { setError(err instanceof Error ? err.message : 'Could not load projects.'); }
    finally { setLoading(false); }
  }, [ownerKey]);
  useEffect(() => {
    const timer = window.setTimeout(() => { void fetchProjects(); }, 0);
    return () => window.clearTimeout(timer);
  }, [fetchProjects]);

  const open = (project: Project) => { stageTemplate(normalizeConfig(project.config), project.name); localStorage.setItem('mockly:draft', JSON.stringify({ config: project.config, name: project.name, projectId: project.id })); navigate(`/studio?project=${project.id}`); };
  const duplicate = async (project: Project) => {
    setBusy(true); setMenu(null);
    try { await apiRequest('/api/projects', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ownerKey, name: `${project.name} copy`, config: project.config, device: project.device, screenshotUrl: project.screenshot_url }) }); await fetchProjects(); setNotice('Project duplicated.'); }
    catch (err) { setError(err instanceof Error ? err.message : 'Could not duplicate.'); }
    finally { setBusy(false); }
  };
  const remove = async (project: Project) => {
    if (!window.confirm(`Delete “${project.name}”? This can’t be undone.`)) return;
    setMenu(null);
    try { await apiRequest('/api/projects', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ownerKey, id: project.id }) }); setProjects((items) => items.filter((item) => item.id !== project.id)); setNotice('Project deleted.'); }
    catch (err) { setError(err instanceof Error ? err.message : 'Could not delete.'); }
  };
  const rename = async () => {
    if (!renaming || !name.trim()) return;
    setBusy(true);
    try { await apiRequest('/api/projects', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ownerKey, id: renaming.id, name: name.trim() }) }); setRenaming(null); await fetchProjects(); setNotice('Project renamed.'); }
    catch (err) { setError(err instanceof Error ? err.message : 'Could not rename.'); }
    finally { setBusy(false); }
  };
  const share = async (project: Project) => {
    setMenu(null);
    try {
      await apiRequest('/api/projects', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ownerKey, id: project.id, isShared: true }) });
      const url = `${window.location.origin}/share/${project.id}`;
      try { await navigator.clipboard.writeText(url); setNotice('Public link copied to clipboard.'); }
      catch { window.prompt('Copy your public scene link:', url); setNotice('Your public link is ready.'); }
      await fetchProjects();
    } catch { setError('Could not create the share link. Please try again.'); }
  };

  return <div className="min-h-screen bg-[#f7f7f2] text-[#20231e]"><Header /><main className="mx-auto max-w-[1380px] px-5 py-12 sm:px-8 lg:py-16">
    <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end"><div><p className="mb-4 text-[10px] font-bold uppercase tracking-[.2em] text-[#7d8476]">Your creative shelf</p><h1 className="text-[clamp(42px,5vw,66px)] font-semibold leading-none tracking-[-.06em]">My projects<span className="text-[#8ba456]">.</span></h1><p className="mt-4 text-[14px] text-[#747b6f]">Pick up where you left off, or make a fresh variation.</p></div><Link to="/studio?new=1" className="inline-flex w-fit items-center gap-2 rounded-full bg-[#22261f] px-5 py-3 text-[13px] font-bold text-white"><Plus size={16} /> New mockup</Link></div>
    {notice && <div className="mt-7 flex items-center justify-between rounded-xl bg-[#e6f2cf] px-4 py-3 text-[12px] font-semibold text-[#4a612d]">{notice}<button onClick={() => setNotice('')}><X size={15} /></button></div>}
    {error && <div className="mt-7 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-[12px] text-red-700">{error}<button onClick={() => setError('')} className="ml-3 font-bold underline">Dismiss</button></div>}
    <div className="mt-10">
      {loading ? <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{[1,2,3].map((i) => <div key={i} className="aspect-[4/3.5] animate-pulse rounded-[22px] bg-[#e7e8e1]" />)}</div> : projects.length === 0 ? <div className="rounded-[28px] border border-dashed border-[#cbd0c2] bg-white/40 px-6 py-20 text-center"><div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-[#e8f2d6] text-[#66803d]"><FolderOpen size={25} /></div><h2 className="mt-5 text-2xl font-bold tracking-[-.04em]">A very promising empty shelf.</h2><p className="mx-auto mt-2 max-w-[420px] text-sm leading-6 text-[#7c8375]">Save a scene in the studio and it will appear here, ready to reopen, duplicate or share.</p><Link to="/studio?new=1" className="mt-6 inline-flex items-center gap-2 rounded-full bg-[#22261f] px-5 py-3 text-xs font-bold text-white">Create your first mockup <ExternalLink size={14} /></Link></div> : <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{projects.map((project) => <article key={project.id} className="group relative overflow-visible rounded-[22px] border border-[#dddfd5] bg-white">
        <button onClick={() => open(project)} className="block w-full overflow-hidden rounded-t-[21px] bg-[#e8e9e2] p-4 text-left"><div className="aspect-[4/3]"><MockupCanvas config={normalizeConfig(project.config)} className="h-full w-full rounded-xl shadow-sm transition-transform duration-500 group-hover:scale-[1.02]" /></div></button>
        <div className="flex items-center justify-between gap-3 border-t border-[#e5e6df] p-4"><button onClick={() => open(project)} className="min-w-0 text-left"><h2 className="truncate text-[15px] font-bold tracking-[-.02em]">{project.name}</h2><p className="mt-1 text-[10px] text-[#8b9185]">Edited {new Date(project.updated_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}{project.is_shared ? ' · Shared' : ''}</p></button><button onClick={() => setMenu(menu === project.id ? null : project.id)} className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-[#e0e2da] text-[#747b6e] hover:bg-[#f0f1eb]" aria-label="Project actions"><MoreHorizontal size={18} /></button></div>
        <AnimatePresence>{menu === project.id && <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }} className="absolute bottom-14 right-4 z-20 w-44 rounded-xl border border-[#dcdfd4] bg-white p-1.5 shadow-xl"><button onClick={() => { setRenaming(project); setName(project.name); setMenu(null); }} className="flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-left text-xs font-semibold hover:bg-[#f1f2ec]"><Pencil size={14} /> Rename</button><button onClick={() => duplicate(project)} className="flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-left text-xs font-semibold hover:bg-[#f1f2ec]"><Copy size={14} /> Duplicate</button><button onClick={() => share(project)} className="flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-left text-xs font-semibold hover:bg-[#f1f2ec]"><Share2 size={14} /> Copy public link</button><button onClick={() => remove(project)} className="flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-left text-xs font-semibold text-red-600 hover:bg-red-50"><Trash2 size={14} /> Delete</button></motion.div>}</AnimatePresence>
      </article>)}</div>}
    </div>
  </main>
  <AnimatePresence>{renaming && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 grid place-items-center bg-[#151812]/50 p-5 backdrop-blur-sm" onMouseDown={() => setRenaming(null)}><motion.form initial={{ scale: .96, y: 10 }} animate={{ scale: 1, y: 0 }} onSubmit={(e) => { e.preventDefault(); rename(); }} onMouseDown={(e) => e.stopPropagation()} className="w-full max-w-md rounded-[22px] bg-[#f9f9f5] p-6 shadow-2xl"><div className="flex items-center justify-between"><h2 className="text-xl font-bold tracking-[-.03em]">Rename project</h2><button type="button" onClick={() => setRenaming(null)}><X size={19} /></button></div><label className="mt-6 block text-[11px] font-bold text-[#747b6e]">PROJECT NAME</label><input autoFocus value={name} onChange={(e) => setName(e.target.value)} maxLength={80} className="mt-2 h-12 w-full rounded-xl border border-[#d7dad0] bg-white px-4 text-sm outline-none focus:border-[#92a66a]" /><button disabled={busy || !name.trim()} className="mt-5 h-11 w-full rounded-xl bg-[#22261f] text-xs font-bold text-white disabled:opacity-50">{busy ? 'Saving…' : 'Save name'}</button></motion.form></motion.div>}</AnimatePresence>
  {busy && <div className="fixed bottom-5 left-1/2 -translate-x-1/2 rounded-full bg-[#22261f] px-4 py-2 text-xs font-semibold text-white shadow-lg">Working…</div>}
  </div>;
}
