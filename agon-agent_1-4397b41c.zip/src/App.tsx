import { lazy, Suspense, useEffect } from 'react';
import { BrowserRouter, Route, Routes, useLocation } from 'react-router-dom';
import { LoaderCircle } from 'lucide-react';
import LandingPage from './pages/LandingPage';

const StudioPage = lazy(() => import('./pages/StudioPage'));
const GalleryPage = lazy(() => import('./pages/GalleryPage'));
const ProjectsPage = lazy(() => import('./pages/ProjectsPage'));
const SharePage = lazy(() => import('./pages/SharePage'));

function RouteEffects() {
  const location = useLocation();
  useEffect(() => {
    if (!location.hash) window.scrollTo(0, 0);
  }, [location.pathname, location.hash]);
  return null;
}

function PageLoader() {
  return <div className="flex min-h-screen items-center justify-center gap-3 bg-[#f7f7f2] text-xs font-semibold text-[#75806b]"><LoaderCircle size={18} className="animate-spin" /> Preparing Mockly…</div>;
}

export default function App() {
  return <BrowserRouter><RouteEffects /><Suspense fallback={<PageLoader />}><Routes>
    <Route path="/" element={<LandingPage />} />
    <Route path="/studio" element={<StudioPage />} />
    <Route path="/gallery" element={<GalleryPage />} />
    <Route path="/projects" element={<ProjectsPage />} />
    <Route path="/share/:id" element={<SharePage />} />
    <Route path="*" element={<LandingPage />} />
  </Routes></Suspense></BrowserRouter>;
}
